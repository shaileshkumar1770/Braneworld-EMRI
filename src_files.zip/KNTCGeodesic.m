(* ::Package:: *)

(* ::Title:: *)
(*ConstantsOfMotion subpackage of KerrGeodesics*)


(* ::Section:: *)
(*Define usage for public functions*)


KerrGeoEnergy::usage = "KerrGeoEnergy[a, p, e, x] returns the orbital energy."
KerrGeoAngularMomentum::usage = "KerrGeoAngularMomentum[a, p, e, x] returns the orbital angular momentum about the symmetry axis."
KerrGeoCarterConstant::usage = "KerrGeoCarterConstant[a, p, e, x] returns the Carter constant of the orbit."
KerrGeoConstantsOfMotion::usage = "KerrGeoConstantsOfMotion[a, p, e, x] returns the three constants of motion."
(*KerrGeoVelocityAtInfinity::usage = "KerrGeoVelocityAtInfinity[a, p, e, x] returns the magnitude of the velocity at infinity of a scatter orbit."
KerrGeoImpactParameter::usage = "KerrGeoImpactParameter[a, p, e, x] returns the impact parameter of a scatter orbit."*)



(* ::Section:: *)
(*Schwarzschild (a=0)*)


(* ::Subsection:: *)
(*Circular (e=0)*)


KerrGeoEnergy[0,p_,0,x_]:=(-2+p)/Sqrt[(-3+p) p]


KerrGeoAngularMomentum[0,p_,0,x_]:=(p x)/Sqrt[-3+p]


KerrGeoCarterConstant[0,p_,0,x_]:=-((p^2 (-1+x^2))/(-3+p))


(* ::Subsection:: *)
(*Eccentric*)


KerrGeoEnergy[0,p_,e_,x_]:=Sqrt[(-4 e^2+(-2+p)^2)/(p (-3-e^2+p))]


KerrGeoAngularMomentum[0,p_,e_,x_]:=(p x)/Sqrt[-3-e^2+p]


KerrGeoCarterConstant[0,p_,e_,x_]:=(p^2 (-1+x^2))/(3+e^2-p)


(* ::Subsection:: *)
(*Scatter*)


KerrGeoVelocityAtInfinity[0,p_,e_/;e>1,x_]:=Module[{En},
	En = KerrGeoEnergy[0,p,e,x];
	Sqrt[En^2-1]/En
]


KerrGeoImpactParameter[0,p_,e_/;e>1,x_]:=KerrGeoAngularMomentum[0,p,e,x]/Sqrt[KerrGeoEnergy[0,p,e,x]^2-1]


(* ::Text:: *)
(*Schwarzschild hyperbolic scatter angle*)
(*Defined as \[Phi](SuperPlus[\[ScriptCapitalI]])-\[Phi](SuperMinus[\[ScriptCapitalI]]) - \[Pi] e.g. Eq. (29) of arXiv:2209.03740 *)


KerrGeoScatteringAngle[0,p_,e_/;e>=1,1]:= -\[Pi]+(4 Sqrt[p]EllipticF[ArcCos[-e^(-1)]/2,(4e)/(6+2e-p)])/Sqrt[-6-2e+p]


(* ::Subsection:: *)
(*Convenience function to compute all three constants of motion*)


KerrGeoConstantsOfMotion[0,p_,e_,x_]:= 
 <|"\[ScriptCapitalE]" -> KerrGeoEnergy[0,p,e,x],
   "\[ScriptCapitalL]" -> KerrGeoAngularMomentum[0,p,e,x],
   "\[ScriptCapitalQ]" -> KerrGeoCarterConstant[0,p,e,x] |>


KerrGeoConstantsOfMotion[0,p_,e_/;e>=1,x_]:= 
 <|"\[ScriptCapitalE]" -> KerrGeoEnergy[0,p,e,x],
   "\[ScriptCapitalL]" -> KerrGeoAngularMomentum[0,p,e,x],
   "\[ScriptCapitalQ]" -> KerrGeoCarterConstant[0,p,e,x], 
   "\!\(\*SubscriptBox[\(v\), \(\[Infinity]\)]\)" -> KerrGeoVelocityAtInfinity[0,p,e,x],
   "b" -> KerrGeoImpactParameter[0,p,e,x],
   "\[Psi]" -> KerrGeoScatteringAngle[0,p,e,x]
   |>


(* ::Section:: *)
(*Kerr*)


(* ::Subsection:: *)
(*Negative a*)


KerrGeoEnergy[a_?Negative,p_,e_,x_]:=KerrGeoEnergy[-a,p,e,-x]
KerrGeoAngularMomentum[a_?Negative,p_,e_,x_]:=-KerrGeoAngularMomentum[-a,p,e,-x]


(* ::Subsection:: *)
(*Equatorial orbits (x^2 = 1)*)


(* ::Text:: *)
(*The Carter constant is zero for all equatorial orbits*)


KerrGeoCarterConstant[a_,p_,e_,x_/;x^2==1]:=0


(* ::Subsubsection:: *)
(*Circular (e=0)*)


KerrGeoEnergy[a_,p_,0,x_/;x^2==1]:=((-2+p) Sqrt[p]+a/x)/Sqrt[2 a/x p^(3/2)+(-3+p) p^2]


KerrGeoAngularMomentum[a_,p_,0,x_/;x^2==1]:=((a^2+p^2)x-2 a Sqrt[p]) /(p^(3/4) Sqrt[x^2 (-3+p) Sqrt[p]+2 a x])


(* ::Subsubsection:: *)
(*Eccentric*)


(* ::Text:: *)
(*Simplified from Glampedakis and Kennefick, Phys. Rev. D66 (2002) 044002, arXiv:gr-qc/0203086, Eq. 7 and appendix A*)


KerrGeoEnergy[a_,p_,e_,x_/;x^2==1]:= Sqrt[1-((1-e^2) (1+((-1+e^2) (a^2 (1+3 e^2+p)+p (-3-e^2+p-2x Sqrt[(a^6 (-1+e^2)^2+a^2 (-4 e^2+(-2+p)^2) p^2+2 a^4 p (-2+p+e^2 (2+p)))/(p^3 x^2)])))/(-4 a^2 (-1+e^2)^2+(3+e^2-p)^2 p)))/p];


KerrGeoAngularMomentum[a_,p_,e_,x_/;x^2==1]:= p x Sqrt[(a^2 (1+3 e^2+p)+p (-3-e^2+p-2x Sqrt[(a^6 (-1+e^2)^2+a^2 (-4 e^2+(-2+p)^2) p^2+2 a^4 p (-2+p+e^2 (2+p)))/(x^2 p^3)]))/((-4 a^2 (-1+e^2)^2+(3+e^2-p)^2 p)x^2)]+a Sqrt[1-((1-e^2) (1+((-1+e^2) (a^2 (1+3 e^2+p)+p (-3-e^2+p-2x Sqrt[(a^6 (-1+e^2)^2+a^2 (-4 e^2+(-2+p)^2) p^2+2 a^4 p (-2+p+e^2 (2+p)))/(p^3 x^2)])))/(-4 a^2 (-1+e^2)^2+(3+e^2-p)^2 p)))/p];


(* ::Subsubsection:: *)
(*Convenience function to compute all three constants of motion*)


KerrGeoConstantsOfMotion[a_,p_,e_,x:(1|-1)]:=
 <|"\[ScriptCapitalE]" -> KerrGeoEnergy[a,p,e,x],
   "\[ScriptCapitalL]" -> KerrGeoAngularMomentum[a,p,e,x],
   "\[ScriptCapitalQ]" -> KerrGeoCarterConstant[a,p,e,x] |>


(* ::Subsection:: *)
(*Polar orbits (x=0)*)


(* ::Text:: *)
(*The angular momentum is zero for all polar orbits*)


KerrGeoAngularMomentum[a_,p_,e_,(0|0.)]:=0


(* ::Subsubsection:: *)
(*Spherical (e=0)*)


(* ::Text:: *)
(*Simplified formula starting from Stoghianidis & Tsoubelis, Gen. Rel, Grav., vol. 19, No. 12, p. 1235 (1987), Eqs. (17)-(19)*)


KerrGeoEnergy[a_,p_,(0|0.),(0|0.)]:=Sqrt[(p (a^2-2 p+p^2)^2)/((a^2+p^2) (a^2+a^2 p-3 p^2+p^3))]


KerrGeoCarterConstant[a_,p_,(0|0.),(0|0.)]:=(p^2 (a^4+2 a^2 (-2+p) p+p^4))/((a^2+p^2) ((-3+p) p^2+a^2 (1+p)))


(* ::Subsubsection:: *)
(*Eccentric*)


(* ::Text:: *)
(*These equations were worked out by N. Warburton starting with Schmidt's formula*)


KerrGeoEnergy[a_,p_,e_,(0|0.)]:=Sqrt[-((p (a^4 (-1+e^2)^2+(-4 e^2+(-2+p)^2) p^2+2 a^2 p (-2+p+e^2 (2+p))))/(a^4 (-1+e^2)^2 (-1+e^2-p)+(3+e^2-p) p^4-2 a^2 p^2 (-1-e^4+p+e^2 (2+p))))]


KerrGeoCarterConstant[a_,p_,e_,(0|0.)]:= -((p^2 (a^4 (-1+e^2)^2+p^4+2 a^2 p (-2+p+e^2 (2+p))))/(a^4 (-1+e^2)^2 (-1+e^2-p)+(3+e^2-p) p^4-2 a^2 p^2 (-1-e^4+p+e^2 (2+p))))


(* ::Subsubsection:: *)
(*Convenience function to compute all three constants of motion*)


KerrGeoConstantsOfMotion[a_,p_,e_,(0|0.)] :=
 <|"\[ScriptCapitalE]" -> KerrGeoEnergy[a,p,e,0],
   "\[ScriptCapitalL]" -> KerrGeoAngularMomentum[a,p,e,0],
   "\[ScriptCapitalQ]" -> KerrGeoCarterConstant[a,p,e,0] |>


(* ::Subsection:: *)
(*Spherical orbits (e=0)*)


KerrGeoEnergy[a_,p_,(0|0.),x_]:=\[Sqrt](((-3+p) (-2+p)^2 p^5-2 a^5 x (-1+x^2) Sqrt[p^3+a^2 p (-1+x^2)]+a^4 p^2 (-1+x^2) (4-5 p (-1+x^2)+3 p^2 (-1+x^2))-a^6 (-1+x^2)^2 (x^2+p^2 (-1+x^2)-p (1+2 x^2))+a^2 p^3 (4-4 x^2+p (12-7 x^2)-3 p^3 (-1+x^2)+p^2 (-13+10 x^2))+a (-2 p^(9/2) x Sqrt[p^2+a^2 (-1+x^2)]+4 p^3 x Sqrt[p^3+a^2 p (-1+x^2)])+2 a^3 (2 p x (-1+x^2) Sqrt[p^3+a^2 p (-1+x^2)]-x^3 Sqrt[p^7+a^2 p^5 (-1+x^2)]))/((p^2-a^2 (-1+x^2)) ((-3+p)^2 p^4-2 a^2 p^2 (3+2 p-3 x^2+p^2 (-1+x^2))+a^4 (-1+x^2) (-1+x^2+p^2 (-1+x^2)-2 p (1+x^2)))))


KerrGeoAngularMomentum[a_,p_,(0|0.),x_,En1_:Null]:=Block[{En=En1,g,d,h,f},
If[En==Null,En=KerrGeoEnergy[a,p,0,x]];
g=2 a p;
d=(a^2+(-2+p) p) (p^2-a^2 (-1+x^2));
h=((-2+p) p-a^2 (-1+x^2))/x^2;
f=p^4+a^2 (p (2+p)-(a^2+(-2+p) p) (-1+x^2));
(-En g + x Sqrt[(-d h + En^2 (g^2+ f h))/x^2])/h
]


(* ::Text:: *)
(*CarterConstant and ConstantsOfMotion calculations are covered by the generic case*)


(* ::Subsection:: *)
(*Marginally bound orbits (e = 1)*)


KerrGeoEnergy[a_,p_,e_/;e==1,x_]:=1


KerrGeoAngularMomentum[a_,p_,e_/;e==1,x_,En1_:Null]:= Module[{En=En1,\[Rho]2},
	If[En==Null,En=KerrGeoEnergy[a,p,e,x]];
	\[Rho]2=p/(1+e);
	((x^2) (-2 a \[Rho]2+Sqrt[2] /x Sqrt[\[Rho]2 (a^2+(-2+\[Rho]2) \[Rho]2) (a^2 (1-x^2)+\[Rho]2^2)]) )/(a^2 (1-x^2)+(-2+\[Rho]2) \[Rho]2)
]



(* ::Subsection:: *)
(*Generic orbits*)


KerrGeoEnergy[a_,p_,e_,x_]:= Module[{r1,r2,zm,\[CapitalDelta],f,g,h,d,\[Kappa],\[Rho],\[Epsilon],\[Sigma],\[Eta],r},
	
	r1 = p/(1-e);
	r2 = p/(1+e);

	zm = Sqrt[1-x^2];

    \[CapitalDelta][r_] = r^2 - 2 r + a^2;

    f[r_] = r^4 + a^2 (r (r + 2) + zm^2 \[CapitalDelta][r]);
    g[r_] = 2 a r;
    h[r_] = r (r - 2) + zm^2/(1 - zm^2) \[CapitalDelta][r];
    d[r_] = (r^2 + a^2 zm^2) \[CapitalDelta][r];
    
    \[Kappa] = d[r1] h[r2] - h[r1] d[r2];
    \[Epsilon] = d[r1] g[r2] - g[r1] d[r2];
    \[Rho] = f[r1] h[r2] - h[r1] f[r2];
    \[Eta] = f[r1] g[r2] - g[r1] f[r2];
    \[Sigma] = g[r1] h[r2] - h[r1] g[r2];

	Sqrt[(\[Kappa] \[Rho] + 2 \[Epsilon] \[Sigma] - x 2 Sqrt[\[Sigma] (\[Sigma] \[Epsilon]^2 + \[Rho] \[Epsilon] \[Kappa] - \[Eta] \[Kappa]^2)/x^2])/(\[Rho]^2 + 4 \[Eta] \[Sigma])]
]


KerrGeoAngularMomentum[a_,p_,e_,x_,En1_:Null]:= Module[{En=En1,r1,zm,\[CapitalDelta],f,g,h,d,r},
	If[En==Null,En=KerrGeoEnergy[a,p,e,x]];
	
	r1 = p/(1-e);

	zm = Sqrt[1-x^2];

    \[CapitalDelta][r_] = r^2 - 2 r + a^2;

    f[r_] = r^4 + a^2 (r (r + 2) + zm^2 \[CapitalDelta][r]);
    g[r_] = 2 a r;
    h[r_] = r (r - 2) + zm^2/(1 - zm^2) \[CapitalDelta][r];
    d[r_] = (r^2 + a^2 zm^2) \[CapitalDelta][r];
    
    (-En g[r1] + x Sqrt[(-d[r1] h[r1] + En^2 (g[r1]^2+ f[r1] h[r1]))/x^2])/h[r1]
]


KerrGeoCarterConstant[a_,p_,e_,x_,En1_:Null,L1_:Null]:= Module[{En=En1,L=L1,zm},
	If[En==Null,En=KerrGeoEnergy[a,p,e,x]];
	If[L==Null,L= KerrGeoAngularMomentum[a,p,e,x,En]];
    zm = Sqrt[1-x^2];
	
	zm^2 (a^2 (1 - En^2) + L^2/(1 - zm^2))
]


KerrGeoConstantsOfMotion[a_,p_,e_,x_] :=Module[{En,L},
  En = KerrGeoEnergy[a,p,e,x];
  L = KerrGeoAngularMomentum[a,p,e,x];

 <|"\[ScriptCapitalE]" -> En, "\[ScriptCapitalL]" -> L, "\[ScriptCapitalQ]" -> KerrGeoCarterConstant[a,p,e,x,En,L] |>
 ]


KerrGeoConstantsOfMotionN[a_, p_, e_, Q_] := Module[{En, Lz},
  En = \[Sqrt]((-((7 + e^2) p^5) + 
        p^6 - (11 - 5 e^2 - 7 e^4 + e^6) p Q^2 + 
        2 (-1 + e^2 + e^4 - e^6) Q^3 - 4 p^4 (-4 + Q + e^2 Q) - 
        a^2 (-1 + e^2)^2 (p + Q) ((-5 + e^2) p + 3 p^2 - 
           2 (1 + e^2) Q) + 2 (3 + e^2) p^3 (-2 + 3 Q + e^2 (2 + Q)) +
         p^2 Q (5 (-4 + Q) + e^4 (12 + 5 Q) + e^2 (8 + 6 Q)) - 
        2 a (-1 + 
           e^2)^2 \[Sqrt]((p + Q)^3 (a^4 (-1 + e^2)^2 - 4 p^3 + p^4 - 
              4 (-1 + e^2) p Q + (-1 + e^2)^2 Q^2 + 
              2 a^2 (2 (-1 + e^2) p + (1 + e^2) p^2 - (-1 + 
                    e^2)^2 Q) - 
              2 p^2 (-2 + Q + e^2 (2 + Q)))))/(p^2 (-4 a^2 (-1 + 
             e^2)^2 (p + Q) + ((3 + e^2) p - p^2 + 2 (1 + e^2) Q)^2)));
  Lz = (\[Sqrt]((-((7 + e^2) p^5) + 
           p^6 - (11 - 5 e^2 - 7 e^4 + e^6) p Q^2 + 
           2 (-1 + e^2 + e^4 - e^6) Q^3 - 4 p^4 (-4 + Q + e^2 Q) - 
           a^2 (-1 + e^2)^2 (p + Q) ((-5 + e^2) p + 3 p^2 - 
              2 (1 + e^2) Q) + 
           2 (3 + e^2) p^3 (-2 + 3 Q + e^2 (2 + Q)) + 
           p^2 Q (5 (-4 + Q) + e^4 (12 + 5 Q) + e^2 (8 + 6 Q)) - 
           2 a (-1 + 
              e^2)^2 \[Sqrt]((p + Q)^3 (a^4 (-1 + e^2)^2 - 4 p^3 + 
                 p^4 - 4 (-1 + e^2) p Q + (-1 + e^2)^2 Q^2 + 
                 2 a^2 (2 (-1 + e^2) p + (1 + e^2) p^2 - (-1 + 
                    e^2)^2 Q) - 
                 2 p^2 (-2 + Q + e^2 (2 + Q)))))/(p^2 (-4 a^2 (-1 + 
                e^2)^2 (p + Q) + ((3 + e^2) p - p^2 + 
               2 (1 + e^2) Q)^2))) (a^3 (-1 + e^2)^2 (p + Q)^2 - 
        p^2 \[Sqrt]((p + Q)^3 (a^4 (-1 + e^2)^2 - 4 p^3 + p^4 - 
              4 (-1 + e^2) p Q + (-1 + e^2)^2 Q^2 + 
              2 a^2 (2 (-1 + e^2) p + (1 + e^2) p^2 - (-1 + 
                    e^2)^2 Q) - 2 p^2 (-2 + Q + e^2 (2 + Q)))) + 
        a (p + Q) ((3 + e^2) p^3 + 
           4 (-1 + e^2) p Q - (-1 + e^2)^2 Q^2 + 
           2 p^2 (-2 + Q + e^2 (2 + Q)))))/((p + Q) (4 p^3 - p^4 + 
        4 (-1 + e^2) p Q - (-1 + e^2)^2 Q^2 + 
        a^2 (-1 + e^2)^2 (p + Q) + 2 p^2 (-2 + Q + e^2 (2 + Q))));        
        
        
 <|"\[ScriptCapitalE]" -> En, "\[ScriptCapitalL]" -> Lz, "\[ScriptCapitalQ]" -> 0 |>
  ]


(* ::Section:: *)
(*KerrGeoVelocity*)


KerrGeoVelocityMino[a_,p_,e_,x_,Qc_,initPhases_,index_ ]:= Module[{En,L,Q,r,z,r1,r2,r3,r4,kr,zp,zm,kz, \[CapitalUpsilon]r, \[CapitalUpsilon]z, 
qr, qz, \[Lambda]local ,qr0, qz0, rprime, zprime, \[CapitalDelta], \[CapitalSigma], \[Omega], utContra,urContra,u\[Theta]Contra,uzContra,u\[Phi]Contra, utCo, urCo, u\[Theta]Co, u\[Phi]Co},

(*Constants of Motion*)
{En,L,Q}= {"\[ScriptCapitalE]","\[ScriptCapitalL]","\[ScriptCapitalQ]"}/.KerrGeoConstantsOfMotionN[a,p,e,Qc];

(*Roots*)
r1 = p/(1-e);
r2 = p/(1+e);
zm = Sqrt[1-x^2];

(*Other Roots*)
r3 = 1/(1-En^2) - (r1 + r2)/2 + Sqrt[(-(1/(1-En^2)) + (r1 + r2)/2 )^2 - (a^2 Q)/(r1 r2 (1 - En^2))];
r4  =  (a^2  Q)/(r1 r2 r3 (1-En^2));

zp = Sqrt[a^2 (1 - En^2) + (L^2)/(1 - zm^2) ]; 
kr = ((r1-r2)(r3-r4))/((r1-r3)(r2-r4));

kz = a^2 (1-En^2) zm^2/zp^2;

(*Frequencies*)
\[CapitalUpsilon]r = \[Pi]/(2 EllipticK[kr]) Sqrt[(1 - En^2)(r1 - r3)(r2 - r4)]; 
\[CapitalUpsilon]z = (\[Pi] zp)/(2EllipticK[kz] ); 

(*Action Angle Phases*)
{ qr0, qz0} = {initPhases[[1]], initPhases[[2]]};

qr[\[Lambda]_] := \[Lambda] \[CapitalUpsilon]r + qr0;
qz[\[Lambda]_] := \[Lambda] \[CapitalUpsilon]z + qz0  + \[Pi]/2;
 
(*r(qr)*)
r[qr_] := (r3(r1 - r2)JacobiSN[EllipticK[kr]/\[Pi] qr, kr] ^2- r2(r1-r3) )/((r1-r2)JacobiSN[EllipticK[kr] /\[Pi] qr, kr]^2-(r1-r3)) ;  
(*r'(qr)*)
rprime[qr_] := (2 (r1-r2) (r1-r3) (r2-r3) EllipticK[kr] JacobiCN[( qr EllipticK[kr])/\[Pi],kr] JacobiDN[( qr EllipticK[kr])/\[Pi],kr] JacobiSN[( qr EllipticK[kr])/\[Pi],kr])/(\[Pi] (-r1+r3+(r1-r2) JacobiSN[( qr EllipticK[kr])/\[Pi],kr]^2)^2); 

(*z(qz)*)
z[qz_] := zm JacobiSN[EllipticK[kz] (2 qz)/\[Pi], kz];
(*z'(qz)*)
zprime[qz_] := (2 zm EllipticK[kz] JacobiCN[(2 qz EllipticK[kz])/\[Pi],kz] JacobiDN[(2 qz EllipticK[kz])/\[Pi],kz])/\[Pi] ;

\[CapitalDelta][qr_]:= r[qr]^2 + a^2 - 2 r[qr];
\[Omega][qr_] := Sqrt[r[qr]^2+ a^2];  
\[CapitalSigma][qr_,qz_] := r[qr]^2 + a^2 z[qz]^2; 

If[index == "Contravariant", 

utContra= Function[{Global`\[Lambda]},Evaluate[1/\[CapitalSigma][qr[Global`\[Lambda]],qz[Global`\[Lambda]]] (\[Omega][qr[Global`\[Lambda]]]^2/\[CapitalDelta][qr[Global`\[Lambda]]] ( \[Omega][qr[Global`\[Lambda] ]]^2 En  - a L) - a^2 (1-z[qz[Global`\[Lambda]]]^2)En + a L)], Listable];
urContra:= Function[{Global`\[Lambda]},Evaluate[( rprime[qr[Global`\[Lambda]]] \[CapitalUpsilon]r)/\[CapitalSigma][qr[Global`\[Lambda]],qz[Global`\[Lambda]]]],Listable];
u\[Theta]Contra = Function[{Global`\[Lambda]}, Evaluate[-(\[CapitalUpsilon]z zprime[qz[Global`\[Lambda]]])/(\[CapitalSigma][qr[Global`\[Lambda]],qz[Global`\[Lambda]]]Sqrt[1-z[qz[Global`\[Lambda]]]^2])],Listable];
u\[Phi]Contra = Function[{Global`\[Lambda]},Evaluate[1/\[CapitalSigma][qr[Global`\[Lambda]],qz[Global`\[Lambda]]] (a/\[CapitalDelta][qr[Global`\[Lambda]]] ( \[Omega][qr[Global`\[Lambda]]]^2 En  - a L) - a En + L/(1-z[qz[Global`\[Lambda]]]^2))],Listable];

<|"\!\(\*SuperscriptBox[\(u\), \(t\)]\)"->utContra, "\!\(\*SuperscriptBox[\(u\), \(r\)]\)"->urContra, "\!\(\*SuperscriptBox[\(u\), \(\[Theta]\)]\)"-> u\[Theta]Contra, "\!\(\*SuperscriptBox[\(u\), \(\[Phi]\)]\)"->   u\[Phi]Contra|>,

(*Else if Index \[Equal] Covariant*)

utCo =  Function[{Global`\[Lambda]},Evaluate[-En], Listable];
urCo= Function[{Global`\[Lambda]},Evaluate[( rprime[qr[Global`\[Lambda]]] \[CapitalUpsilon]r)/\[CapitalDelta][qr[Global`\[Lambda]]]],Listable];
u\[Theta]Co=  Function[{Global`\[Lambda]},Evaluate[-((\[CapitalUpsilon]z zprime[qz[Global`\[Lambda]]])/Sqrt[1-z[qz[Global`\[Lambda]]]^2])],Listable];
u\[Phi]Co= Function[{Global`\[Lambda]},Evaluate[L],Listable];

<|"\!\(\*SubscriptBox[\(u\), \(t\)]\)"->utCo, "\!\(\*SubscriptBox[\(u\), \(r\)]\)"->urCo, "\!\(\*SubscriptBox[\(u\), \(\[Theta]\)]\)"-> u\[Theta]Co, "\!\(\*SubscriptBox[\(u\), \(\[Phi]\)]\)"->   u\[Phi]Co|>
]


]



KerrGeoVelocityDarwin[a_,p_,(0|0.),x_,Qc_,initPhases_,index_ ]:= Module[{ut,ur,u\[Theta],u\[Phi], MinoVelocities,ut1,ur1,u\[Theta]1,u\[Phi]1},

MinoVelocities = KerrGeoVelocityMino[a,p,0,x, Qc,{0,0}, index];

If[index == "Contravariant", 
	ut1="\!\(\*SuperscriptBox[\(u\), \(t\)]\)"; ur1="\!\(\*SuperscriptBox[\(u\), \(r\)]\)"; u\[Theta]1="\!\(\*SuperscriptBox[\(u\), \(\[Theta]\)]\)"; u\[Phi]1="\!\(\*SuperscriptBox[\(u\), \(\[Phi]\)]\)";,
	ut1="\!\(\*SubscriptBox[\(u\), \(t\)]\)"; ur1="\!\(\*SubscriptBox[\(u\), \(r\)]\)"; u\[Theta]1="\!\(\*SubscriptBox[\(u\), \(\[Theta]\)]\)"; u\[Phi]1="\!\(\*SubscriptBox[\(u\), \(\[Phi]\)]\)";
];
(*All components are Constants*)
ut = Function[{Global`\[Chi]},Evaluate[MinoVelocities [ut1][Global`\[Chi]]], Listable];
ur = Function[{Global`\[Chi]},Evaluate[0],Listable];
u\[Theta]= Function[{Global`\[Chi]},Evaluate[0],Listable];
u\[Phi]= Function[{Global`\[Chi]},Evaluate[MinoVelocities [u\[Phi]1][Global`\[Chi]]],Listable];

<|ut1-> ut, ur1-> ur, u\[Theta]1-> u\[Theta], u\[Phi]1-> u\[Phi] |>

]



KerrGeoVelocityDarwin[a_,p_,e_,x_,Qc_,initPhases_,index_ ]:= Module[{En,L,Q,r,z,r1,r2,r3,r4,kr, \[CapitalUpsilon]r, \[CapitalLambda]r,yr,\[Lambda]0r,r01,\[CapitalLambda]r1,\[Lambda],
\[Chi]0,\[Nu], \[Chi]local ,qr0, qz0, rprime, zprime, \[CapitalDelta], \[CapitalSigma], \[Omega], ut,ur,u\[Theta],u\[Phi], MinoVelocities,ut1,ur1,u\[Theta]1,u\[Phi]1},

(*Constants of Motion*)
{En,L,Q}= {"\[ScriptCapitalE]","\[ScriptCapitalL]","\[ScriptCapitalQ]"}/.KerrGeoConstantsOfMotionN[a,p,e,Qc];

(*Roots*)
r1 = p/(1-e);
r2 = p/(1+e);

(*Other Roots*)
r3 = 1/(1-En^2) - (r1 + r2)/2 + Sqrt[(-(1/(1-En^2)) + (r1 + r2)/2 )^2 - (a^2 Q)/(r1 r2 (1 - En^2))];
r4  =  (a^2  Q)/(r1 r2 r3 (1-En^2));
kr = ((r1-r2)(r3-r4))/((r1-r3)(r2-r4));

(*Frequencies*)
\[CapitalUpsilon]r = \[Pi]/(2 EllipticK[kr]) Sqrt[(1 - En^2)(r1 - r3)(r2 - r4)]; 

(*Initial Phase*)
\[Chi]0 = initPhases[[1]];

(*r(\[Nu] = \[Chi] - \[Chi]0)*)
r[\[Nu]_] = p /(1-e  Cos[\[Nu]] ) ; 

(*Conversion from Mino time to Darwin Parameter*)
\[CapitalLambda]r = (2\[Pi])/\[CapitalUpsilon]r;
yr[r_]:=Sqrt[(r1-r3)/(r1-r2) (r-r2)/(r-r3)];
\[Lambda]0r[r_]:=1/Sqrt[1-En^2] 2/Sqrt[(r1-r3)(r2-r4)] EllipticF[ArcSin[yr[r]],kr];
r01=r2;
\[CapitalLambda]r1=\[Lambda]0r[r01];

\[Lambda][\[Nu]_]:=\[CapitalLambda]r Floor[\[Nu]/(2\[Pi])]+If[Mod[\[Nu],2\[Pi]]<=\[Pi], \[Lambda]0r[r[\[Nu]]]-\[CapitalLambda]r1,\[CapitalLambda]r-\[Lambda]0r[r[\[Nu]]]];


MinoVelocities = KerrGeoVelocityMino[a,p,e,x,Qc,{0,0}, index];

If[index == "Contravariant", 
	ut1="\!\(\*SuperscriptBox[\(u\), \(t\)]\)"; ur1="\!\(\*SuperscriptBox[\(u\), \(r\)]\)"; u\[Theta]1="\!\(\*SuperscriptBox[\(u\), \(\[Theta]\)]\)"; u\[Phi]1="\!\(\*SuperscriptBox[\(u\), \(\[Phi]\)]\)";,
	ut1="\!\(\*SubscriptBox[\(u\), \(t\)]\)"; ur1="\!\(\*SubscriptBox[\(u\), \(r\)]\)"; u\[Theta]1="\!\(\*SubscriptBox[\(u\), \(\[Theta]\)]\)"; u\[Phi]1="\!\(\*SubscriptBox[\(u\), \(\[Phi]\)]\)";
];

ut = Function[{Global`\[Chi]},Evaluate[MinoVelocities [ut1][\[Lambda][Global`\[Chi]-\[Chi]0]]],Listable];
ur = Function[{Global`\[Chi]},Evaluate[MinoVelocities [ur1][\[Lambda][Global`\[Chi]-\[Chi]0]]],Listable];
u\[Theta] = Function[{Global`\[Chi]}, Evaluate[0],Listable];
u\[Phi] = Function[{Global`\[Chi]}, Evaluate[MinoVelocities [u\[Phi]1][\[Lambda][Global`\[Chi]-\[Chi]0]]],Listable];

<|ut1-> ut, ur1-> ur, u\[Theta]1-> u\[Theta], u\[Phi]1-> u\[Phi] |>


]



Options[KerrGeoFourVelocity] = {"Covariant" -> False, "Parametrization"-> "Mino"};
SyntaxInformation[KerrGeoFourVelocity] = {"ArgumentsPattern"->{_,_,_,_,OptionsPattern[]}};


KerrGeoFourVelocity[a_,p_,e_,x_,Qc_,initPhases:{_,_}:{0,0}, OptionsPattern[]]:= Module[{param, index},
param = OptionValue["Parametrization"];

If[OptionValue["Covariant"], index = "Covariant" , index="Contravariant", Message[KerrGeoFourVelocity::opttf,"Covariant",OptionValue["Covariant"]]; Return[] ];


	If[param == "Darwin",

	If[ Abs[x]!=1, 
		Message[KerrGeoFourVelocity::parametrization, "Darwin parameterization only valid for equatorial motion"];
		Return[];,
		 Return[KerrGeoVelocityDarwin[a,p,e,x,Qc,initPhases, index]]]];


	If[param == "Mino", Return[KerrGeoVelocityMino[a,p,e,x,Qc,initPhases, index]]];

	Message[KerrGeoFourVelocity::parametrization, "Unrecognized Paramaterization: " <> param];

]



KerrGeoFourVelocity[0.58,12,0.1,1,0.1,{0,0}, "Parametrization"->"Mino"]["\!\(\*SuperscriptBox[\(u\), \(t\)]\)"][614]



(* ::Subtitle:: *)
(*Frequencies*)


Frequencies[avalue_,p_,e_,Qvalue_]:=Block[{M=1,\[Theta],\[CapitalDelta],\[CapitalSigma],Q=Qvalue,a=avalue,rdot,r1,r2,E1,Jz,gTT,gRR,g\[CapitalTheta]\[CapitalTheta],g\[CapitalPhi]\[CapitalPhi],gT\[CapitalPhi],Veff,Veff1,Veff2,EnerJz,Pr,tdot,\[Phi]dot,\[CapitalOmega]\[Phi],\[CapitalOmega]r,trfunc,
TrOrbits,\[CapitalDelta]\[Phi],En,L,\[Phi]func},

\[Theta]=\[Pi]/2;
\[CapitalDelta]=r^2+a^2-2 M r-Q M^2;
\[CapitalSigma]= r^2+a^2  Cos[\[Theta]]^2;

gTT=- ((\[CapitalDelta]-a^2 Sin[\[Theta]]^2)/\[CapitalSigma]);
gRR=\[CapitalSigma]/\[CapitalDelta];
g\[CapitalTheta]\[CapitalTheta]=\[CapitalSigma];
g\[CapitalPhi]\[CapitalPhi]=Sin[\[Theta]]^2 (((r^2+a^2)^2-\[CapitalDelta] a^2 Sin[\[Theta]]^2)/\[CapitalSigma]);
gT\[CapitalPhi]=-((a Sin[\[Theta]]^2 (r^2+a^2-\[CapitalDelta]))/\[CapitalSigma]);

r1=(p M)/(1+e);
r2=(p M)/(1-e);
{E1,Jz,Q}= {"\[ScriptCapitalE]","\[ScriptCapitalL]","\[ScriptCapitalQ]"}/.KerrGeoConstantsOfMotionN[a,p,e,Q];

Pr=E1 (r^2+a^2)-a Jz;
tdot=1/\[CapitalSigma] (-a (a E1-Jz)+(a^2+r^2)/\[CapitalDelta] Pr);
\[Phi]dot=1/\[CapitalSigma] (-(a E1-Jz)+a/\[CapitalDelta] Pr);

rdot=1/\[CapitalSigma] Sqrt[(Pr^2-\[CapitalDelta](r^2+(Jz-a E1)^2) )];

trfunc[\[Chi]\[Chi]_]:=tdot/rdot/.r->p/(1+e Cos[\[Chi]])/.\[Chi]->\[Chi]\[Chi]//Simplify;

\[Phi]func[\[Chi]\[Chi]_]:=\[Phi]dot/rdot/.r->p/(1+e Cos[\[Chi]])/.\[Chi]->\[Chi]\[Chi]//Simplify;

TrOrbits=2NIntegrate[trfunc[\[Chi]\[Chi]],{\[Chi]\[Chi],0.001,0.99\[Pi]}];


\[CapitalOmega]r=2Pi/TrOrbits;

\[CapitalDelta]\[Phi]=2NIntegrate[\[Phi]func[\[Chi]\[Chi]],{\[Chi]\[Chi],0.001,0.99\[Pi]}];

\[CapitalOmega]\[Phi]=\[CapitalDelta]\[Phi]/TrOrbits;

{SetPrecision[\[CapitalOmega]r,32],SetPrecision[\[CapitalOmega]\[Phi],32]}

]


(* Returns the roots of the radial equation, as given by Fujita and Hikida, En1_:Null,Q1_:Null *)
KerrGeoRadialRoots[a_, p_, e_, x_, Qc_]:=Module[{M=1,En,En1,Q,Q1,E1,Jz,QC,r1,r2,r3,r4,AplusB,AB},
{E1,Jz,QC}= {"\[ScriptCapitalE]","\[ScriptCapitalL]","\[ScriptCapitalQ]"}/.KerrGeoConstantsOfMotionN[a,p,e,Qc];
En=E1;Q=Qc;
r1=p/(1-e);
r2=p/(1+e);
AplusB=(2M)/(1-En^2)-(r1+r2);(*Eq. (11)*)
AB=(a^2 Q)/((1-En^2)r1 r2);(*Eq. (11)*)
r3=(AplusB+Sqrt[(AplusB)^2-4AB])/2;(*Eq. (11)*)
r4=AB/r3;

{r1,r2,r3,r4}

]



(* Returns the roots of the radial equation, as given by Fujita and Hikida *)
KerrGeoRadialRoots[a_, p_, e_, x_, En1_:Null,Q1_:Null] := Module[{M=1,En=En1,Q=Q1,r1,r2,r3,r4,AplusB,AB},
If[En==Null, En = KerrGeoEnergy[a, p, e, x]];
If[Q==Null,  Q = KerrGeoCarterConstant[a, p, e, x]];

r1=p/(1-e);
r2=p/(1+e);
AplusB=(2M)/(1-En^2)-(r1+r2);(*Eq. (11)*)
AB=(a^2 Q)/((1-En^2)r1 r2);(*Eq. (11)*)
r3=(AplusB+Sqrt[(AplusB)^2-4AB])/2;(*Eq. (11)*)
r4=AB/r3;
{r1,r2,r3,r4}
]



KerrGeoRadialRoots[a_, p_, e_/;e==1, x_, En1_:Null,Q1_:Null] := Module[{M=1,En=En1,Q=Q1,r1,r2,r3,r4,\[Rho]2},
r1=\[Infinity];
r2=\[Rho]2=p/(1+e);

r3=1/4 (1-2 \[Rho]2+Sqrt[(8 a^2 (-1+x^2) (-2 a x \[Rho]2+Sqrt[2] Sqrt[\[Rho]2 (a^2+(-2+\[Rho]2) \[Rho]2) (-a^2 (-1+x^2)+\[Rho]2^2)])^2)/(\[Rho]2 (a^2 (-1+x^2)-(-2+\[Rho]2) \[Rho]2)^2)+(4 \[Rho]2^2 (a^4 (x^2-x^4)+2 (-2+\[Rho]2) \[Rho]2^2+a^2 \[Rho]2 (2+x^2 \[Rho]2)-2 Sqrt[2] a x Sqrt[\[Rho]2 (a^2+(-2+\[Rho]2) \[Rho]2) (-a^2 (-1+x^2)+\[Rho]2^2)])^2)/(a^2 (-1+x^2)-(-2+\[Rho]2) \[Rho]2)^4]+(-a^4 (-1+x^2) (-1+x^2+2 \[Rho]2)-4 Sqrt[2] a x \[Rho]2 Sqrt[\[Rho]2 (a^2+(-2+\[Rho]2) \[Rho]2) (-a^2 (-1+x^2)+\[Rho]2^2)]+\[Rho]2^2 (-4+4 \[Rho]2-5 \[Rho]2^2+2 \[Rho]2^3)-2 a^2 \[Rho]2 (-2+3 \[Rho]2-2 \[Rho]2^2+x^2 (2-5 \[Rho]2+\[Rho]2^2)))/(a^2 (-1+x^2)-(-2+\[Rho]2) \[Rho]2)^2);

r4=1/4 (1-2 \[Rho]2-Sqrt[(8 a^2 (-1+x^2) (-2 a x \[Rho]2+Sqrt[2] Sqrt[\[Rho]2 (a^2+(-2+\[Rho]2) \[Rho]2) (-a^2 (-1+x^2)+\[Rho]2^2)])^2)/(\[Rho]2 (a^2 (-1+x^2)-(-2+\[Rho]2) \[Rho]2)^2)+(4 \[Rho]2^2 (a^4 (x^2-x^4)+2 (-2+\[Rho]2) \[Rho]2^2+a^2 \[Rho]2 (2+x^2 \[Rho]2)-2 Sqrt[2] a x Sqrt[\[Rho]2 (a^2+(-2+\[Rho]2) \[Rho]2) (-a^2 (-1+x^2)+\[Rho]2^2)])^2)/(a^2 (-1+x^2)-(-2+\[Rho]2) \[Rho]2)^4]+(-a^4 (-1+x^2) (-1+x^2+2 \[Rho]2)-4 Sqrt[2] a x \[Rho]2 Sqrt[\[Rho]2 (a^2+(-2+\[Rho]2) \[Rho]2) (-a^2 (-1+x^2)+\[Rho]2^2)]+\[Rho]2^2 (-4+4 \[Rho]2-5 \[Rho]2^2+2 \[Rho]2^3)-2 a^2 \[Rho]2 (-2+3 \[Rho]2-2 \[Rho]2^2+x^2 (2-5 \[Rho]2+\[Rho]2^2)))/(a^2 (-1+x^2)-(-2+\[Rho]2) \[Rho]2)^2);

{r1,r2,r3,r4}

]


KerrGeoPolarRoots[a_, p_, e_, x_,Qc_] := Module[{En,L,Q,zm,zp},
  {En,L,Q} = {"\[ScriptCapitalE]","\[ScriptCapitalL]","\[ScriptCapitalQ]"}/.KerrGeoConstantsOfMotionN[a, p, e, Qc];
  zm = Sqrt[1-x^2];
  zp = (a^2 (1-En^2)+L^2/(1-zm^2))^(1/2);
  {zp,zm}
]


KerrGeoPolarRoots[a_, p_, e_, x_?PossibleZeroQ,Qc_] := Module[{En,L,Q,zm,zp},
  {En,L,Q} = Values[KerrGeoConstantsOfMotionN[a, p, e, Qc]];
  zm = Sqrt[1-x^2];
  zp = (Q)^(1/2);
  {zp,zm}
]


sgn[x_]=Piecewise[{{-1,Negative[x]}},1];


KerrGeoMinoFrequencies[a_?PossibleZeroQ, p_, e_?PossibleZeroQ,x_] :=
 <| "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(r\)]\)" -> Sqrt[((-6+p) p)/(-3+p)],
    "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Theta]\)]\)" -> p Sqrt[1/((-3+p))] ,
    "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Phi]\)]\)" -> (p sgn[x])/Sqrt[(-3+p)],
    "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(t\)]\)"  -> Sqrt[p^5/(-3+p)] |>;


KerrGeoMinoFrequencies[a_?PossibleZeroQ, p_,e_,x_] :=
 <| "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(r\)]\)" -> (Sqrt[-((p (-6+2 e+p))/(3+e^2-p))] \[Pi])/(2 EllipticK[(4 e)/(-6+2 e+p)]),
    "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Theta]\)]\)" -> p/Sqrt[-3-e^2+p],
    "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Phi]\)]\)" -> (p sgn[x])/(Sqrt[-3-e^2+p]),
    "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(t\)]\)" -> 1/2 Sqrt[(-4 e^2+(-2+p)^2)/(p (-3-e^2+p))] (8+1/((-4+p)^2 EllipticK[(4 e)/(-6+2 e+p)]) (-(((-4+p) p^2 (-6+2 e+p) EllipticE[(4 e)/(-6+2 e+p)])/(-1+e^2))+(p^2 (28+4 e^2-12 p+p^2) EllipticK[(4 e)/(-6+2 e+p)])/(-1+e^2)-(2 (6+2 e-p) (3+e^2-p) p^2 EllipticPi[(2 e (-4+p))/((1+e) (-6+2 e+p)),(4 e)/(-6+2 e+p)])/((-1+e) (1+e)^2)+(4 (-4+p) p (2 (1+e) EllipticK[(4 e)/(-6+2 e+p)]+(-6-2 e+p) EllipticPi[(2 e (-4+p))/((1+e) (-6+2 e+p)),(4 e)/(-6+2 e+p)]))/(1+e)+2 (-4+p)^2 ((-4+p) EllipticK[(4 e)/(-6+2 e+p)]-((6+2 e-p) p EllipticPi[(16 e)/(12+8 e-4 e^2-8 p+p^2),(4 e)/(-6+2 e+p)])/(2+2 e-p)))) |>;



KerrGeoMinoFrequencies[a_?PossibleZeroQ, p_,e_/;e==1,x_] :=
 <| "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(r\)]\)" -> (Sqrt[-((p (-6+2 e+p))/(3+e^2-p))] \[Pi])/(2 EllipticK[(4 e)/(-6+2 e+p)]),
    "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Theta]\)]\)" -> p/Sqrt[-3-e^2+p],
    "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Phi]\)]\)" -> (p sgn[x])/(Sqrt[-3-e^2+p]),
    "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(t\)]\)"  -> \[Infinity] |>;



KerrGeoBoyerLindquistFrequencies[a_?PossibleZeroQ, p_, e_?PossibleZeroQ,x_] :=
 <| "\!\(\*SubscriptBox[\(\[CapitalOmega]\), \(r\)]\)" -> Sqrt[-6+p]/p^2,
    "\!\(\*SubscriptBox[\(\[CapitalOmega]\), \(\[Theta]\)]\)" -> (1)/p^(3/2),
    "\!\(\*SubscriptBox[\(\[CapitalOmega]\), \(\[Phi]\)]\)" -> (p Sign[x])/Sqrt[p^5] |>;



KerrGeoProperFrequencyFactor[_,p_,e_/;e==1,x_]:=\[Infinity]


KerrGeoProperFrequencyFactor[a_?PossibleZeroQ, p_, e_?PossibleZeroQ,x_]:=p^2


KerrGeoProperFrequencyFactor[a_?PossibleZeroQ ,p_,e_,x_]:=(p^2 ((1+e) (28+4 e^2+(-12+p) p)-((1+e) (-4+p) (-6+2 e+p) EllipticE[(4 e)/(-6+2 e+p)]+2 (6+2 e-p) (3+e^2-p) EllipticPi[(2 e (-4+p))/((1+e) (-6+2 e+p)),(4 e)/(-6+2 e+p)])/EllipticK[(4 e)/(-6+2 e+p)]))/(2 (-1+e) (1+e)^2 (-4+p)^2)


(* ::Subsubsection:: *)
(*KerrGeoMinoFrequencyr*)


KerrGeoMinoFrequencyr[a_,p_,e_,x_,{En_,L_,Q_},{\[Rho]1_,\[Rho]2_,\[Rho]3_,\[Rho]4_}]:=Module[{kr},
	kr= (\[Rho]1-\[Rho]2)/(\[Rho]1-\[Rho]3) (\[Rho]3-\[Rho]4)/(\[Rho]2-\[Rho]4);
	(\[Pi] Sqrt[(1-En^2)(\[Rho]1-\[Rho]3)(\[Rho]2-\[Rho]4)])/(2 EllipticK[kr])
]


KerrGeoMinoFrequencyr[a_,p_,e_/;e==1,x_,{En_,L_,Q_},{\[Rho]1_,\[Rho]2_,\[Rho]3_,\[Rho]4_}]:=Module[{kr},
	kr=(\[Rho]3-\[Rho]4)/(\[Rho]2-\[Rho]4);
	(\[Pi] Sqrt[2(\[Rho]2-\[Rho]4)])/(2 EllipticK[kr])
]


KerrGeoMinoFrequencyr[a_?PossibleZeroQ,p_,e_?PossibleZeroQ,x_,{En_,L_,Q_},{\[Rho]1_,\[Rho]2_,\[Rho]3_,\[Rho]4_}]:=Module[{},
	Sqrt[((-6+p) p)/(-3+p)]
]


(* ::Subsubsection:: *)
(*KerrGeoMinoFrequency\[Theta]*)


KerrGeoMinoFrequency\[Theta][a_,p_,e_,x_,{En_,L_,Q_},{zp_,zm_}]:=Module[{},
   (\[Pi]  zp)/(2EllipticK[a^2 (1-En^2)(zm/zp)^2])
]

KerrGeoMinoFrequency\[Theta][a_,p_,e_/;e==1,x_,{En_,L_,Q_},{zp_,zm_}]:=Module[{},
  zp
]



(* ::Subsubsection:: *)
(*KerrGeoMinoFrequency\[Phi]*)


KerrGeoMinoFrequency\[Phi][a_,p_,e_,x_,{En_,L_,Q_},{\[Rho]1_,\[Rho]2_,\[Rho]3_,\[Rho]4_},{zp_,zm_}]:=
KerrGeoMinoFrequency\[Phi]r[a,p,e,x,{En,L,Q},{\[Rho]1,\[Rho]2,\[Rho]3,\[Rho]4}]+KerrGeoMinoFrequency\[Phi]\[Theta][a,p,e,x,{En,L,Q},{zp,zm}]


KerrGeoMinoFrequency\[Phi]r[a_,p_,e_,x_,{En_,L_,Q_},{\[Rho]1_,\[Rho]2_,\[Rho]3_,\[Rho]4_}]:=Module[{\[Rho]in,\[Rho]out,kr,hin,hout},
	\[Rho]in= 1-Sqrt[1-a^2];\[Rho]out= 1+Sqrt[1-a^2];
	kr= (\[Rho]1-\[Rho]2)/(\[Rho]1-\[Rho]3) (\[Rho]3-\[Rho]4)/(\[Rho]2-\[Rho]4);
	hout= (\[Rho]1-\[Rho]2)/(\[Rho]1-\[Rho]3) (\[Rho]3-\[Rho]out)/(\[Rho]2-\[Rho]out);
	hin= (\[Rho]1-\[Rho]2)/(\[Rho]1-\[Rho]3) (\[Rho]3-\[Rho]in)/(\[Rho]2-\[Rho]in);
	 a/(2Sqrt[1-a^2]) ((2 En \[Rho]out-a L)/(\[Rho]3-\[Rho]out) (1-(\[Rho]2-\[Rho]3)/(\[Rho]2-\[Rho]out) EllipticPi[hout,kr]/EllipticK[kr])-(2 En \[Rho]in-a L)/(\[Rho]3-\[Rho]in) (1-(\[Rho]2-\[Rho]3)/(\[Rho]2-\[Rho]in) EllipticPi[hin,kr]/EllipticK[kr]))
]

KerrGeoMinoFrequency\[Phi]r[a_/;a^2==1,p_,e_,x_,{En_,L_,Q_},{\[Rho]1_,\[Rho]2_,\[Rho]3_,\[Rho]4_}]:=Module[{\[Rho]in,\[Rho]out,kr,hM},
	\[Rho]in= 1-Sqrt[1-a^2];\[Rho]out= 1+Sqrt[1-a^2];
	kr= (\[Rho]1-\[Rho]2)/(\[Rho]1-\[Rho]3) (\[Rho]3-\[Rho]4)/(\[Rho]2-\[Rho]4);
	hM= (\[Rho]1-\[Rho]2)/(\[Rho]1-\[Rho]3) (\[Rho]3-1)/(\[Rho]2-1);
	a En(2/(\[Rho]3-1) (1-(\[Rho]2-\[Rho]3)/(\[Rho]2-1) EllipticPi[hM,kr]/EllipticK[kr])+(2-a L/En)/(2(\[Rho]3-1)^2) ((2-((\[Rho]1-\[Rho]3)(\[Rho]2-\[Rho]3))/((\[Rho]1-1)(\[Rho]2-1)))+((\[Rho]1-\[Rho]3)(\[Rho]2-\[Rho]4)(\[Rho]3-1))/((\[Rho]1-1)(\[Rho]2-1)(\[Rho]4-1)) EllipticE[kr]/EllipticK[kr]+(\[Rho]2-\[Rho]3)/(\[Rho]2-1) ((\[Rho]1-\[Rho]3)/(\[Rho]1-1)+(\[Rho]2-\[Rho]3)/(\[Rho]2-1)+(\[Rho]4-\[Rho]3)/(\[Rho]4-1)-4) EllipticPi[hM,kr]/EllipticK[kr]))
]



KerrGeoMinoFrequency\[Phi]r[a_,p_,e_/;e==1,x_,{En_,L_,Q_},{\[Rho]1_,\[Rho]2_,\[Rho]3_,\[Rho]4_}]:=Module[{\[Rho]in,\[Rho]out,kr,hin,hout},
	\[Rho]in= 1-Sqrt[1-a^2];
	\[Rho]out= 1+Sqrt[1-a^2];
	kr= (\[Rho]3-\[Rho]4)/(\[Rho]2-\[Rho]4);
	hout= (\[Rho]3-\[Rho]out)/(\[Rho]2-\[Rho]out);
	hin= (\[Rho]3-\[Rho]in)/(\[Rho]2-\[Rho]in);
	 a/(2Sqrt[1-a^2]) ((2  \[Rho]out-a L)/(\[Rho]3-\[Rho]out) (1-(\[Rho]2-\[Rho]3)/(\[Rho]2-\[Rho]out) EllipticPi[hout,kr]/EllipticK[kr])-(2  \[Rho]in-a L)/(\[Rho]3-\[Rho]in) (1-(\[Rho]2-\[Rho]3)/(\[Rho]2-\[Rho]in) EllipticPi[hin,kr]/EllipticK[kr]))
]


KerrGeoMinoFrequency\[Phi]r[a_/;a^2==1,p_,e_/;e==1,x_,{En_,L_,Q_},{\[Rho]1_,\[Rho]2_,\[Rho]3_,\[Rho]4_}]:=Module[{kr,hM},
	kr= (\[Rho]3-\[Rho]4)/(\[Rho]2-\[Rho]4);
	hM= (\[Rho]3-1)/(\[Rho]2-1);
	  a(2/(\[Rho]3-1) (1-(\[Rho]2-\[Rho]3)/(\[Rho]2-1) EllipticPi[hM,kr]/EllipticK[kr])+(2-a L)/(2(\[Rho]3-1)^2) ((2-(\[Rho]2-\[Rho]3)/(\[Rho]2-1))+((\[Rho]2-\[Rho]4)(\[Rho]3-1))/((\[Rho]2-1)(\[Rho]4-1)) EllipticE[kr]/EllipticK[kr]+(\[Rho]2-\[Rho]3)/(\[Rho]2-1) (1+(\[Rho]2-\[Rho]3)/(\[Rho]2-1)+(\[Rho]4-\[Rho]3)/(\[Rho]4-1)-4) EllipticPi[hM,kr]/EllipticK[kr]))
]


KerrGeoMinoFrequency\[Phi]\[Theta][a_,p_,e_,x_,{En_,L_,Q_},{zp_,zm_}]:=Module[{},
    ( L EllipticPi[zm^2,a^2 (1-En^2)(zm/zp)^2])/EllipticK[a^2 (1-En^2)(zm/zp)^2]
]


KerrGeoMinoFrequency\[Phi]\[Theta][a_,p_,e_,x_?PossibleZeroQ,Qc_,{En_,L_,Q_},{zp_,zm_}]:=Module[{\[Rho]1,\[Rho]2,\[Rho]3,\[Rho]4},
{\[Rho]1,\[Rho]2,\[Rho]3,\[Rho]4} = KerrGeoRadialRoots[a,p,e,x,Qc];
\[Pi] Sqrt[((\[Rho]1 \[Rho]2 (a^4+\[Rho]1^2 \[Rho]2^2+a^2 ((-2+\[Rho]1) \[Rho]1+(-2+\[Rho]2) \[Rho]2))/2)/(a^4 (2+\[Rho]1+\[Rho]2)+\[Rho]1 \[Rho]2 (\[Rho]1^2 (-2+\[Rho]2)+\[Rho]1 (-2+\[Rho]2) \[Rho]2-2 \[Rho]2^2)+a^2 (\[Rho]1^3+\[Rho]1^2 \[Rho]2+\[Rho]1 (-4+\[Rho]2) \[Rho]2+\[Rho]2^3)))]/EllipticK[(a^2 (a^4+\[Rho]1 (\[Rho]1 (-2+\[Rho]2)-2 \[Rho]2) \[Rho]2+a^2 (\[Rho]1^2+\[Rho]2^2)))/(\[Rho]1 \[Rho]2 (a^4+\[Rho]1^2 \[Rho]2^2+a^2 ((-2+\[Rho]1) \[Rho]1+(-2+\[Rho]2) \[Rho]2)))]
]


KerrGeoMinoFrequency\[Phi]\[Theta][a_,p_,e_/;e==1,x_?PossibleZeroQ,Qc_,{En_,L_,Q_},{zp_,zm_}]:=Module[{\[Rho]1,\[Rho]2,\[Rho]3,\[Rho]4},
{\[Rho]1,\[Rho]2,\[Rho]3,\[Rho]4} = KerrGeoRadialRoots[a,p,e,x,Qc];
 Sqrt[2] Sqrt[(\[Rho]2 (a^2+\[Rho]2^2))/(a^2+(-2+\[Rho]2) \[Rho]2)]
]


(* ::Subsubsection:: *)
(*KerrGeoMinoFrequencyt*)


KerrGeoMinoFrequencyt[a_,p_,e_,x_,{En_,L_,Q_},{\[Rho]1_,\[Rho]2_,\[Rho]3_,\[Rho]4_},{zp_,zm_}]:=KerrGeoMinoFrequencytr[a,p,e,x,{En,L,Q},{\[Rho]1,\[Rho]2,\[Rho]3,\[Rho]4}]+KerrGeoMinoFrequencyt\[Theta][a,p,e,x,{En,L,Q},{zp,zm}]


KerrGeoMinoFrequencytr[a_,p_,e_,x_,{En_,L_,Q_},{\[Rho]1_,\[Rho]2_,\[Rho]3_,\[Rho]4_}]:=Module[{\[Rho]in,\[Rho]out,kr,hin,hout,hr},
	\[Rho]in= 1-Sqrt[1-a^2];\[Rho]out= 1+Sqrt[1-a^2];
	kr= (\[Rho]1-\[Rho]2)/(\[Rho]1-\[Rho]3) (\[Rho]3-\[Rho]4)/(\[Rho]2-\[Rho]4);
	hout= (\[Rho]1-\[Rho]2)/(\[Rho]1-\[Rho]3) (\[Rho]3-\[Rho]out)/(\[Rho]2-\[Rho]out);
	hin= (\[Rho]1-\[Rho]2)/(\[Rho]1-\[Rho]3) (\[Rho]3-\[Rho]in)/(\[Rho]2-\[Rho]in);
	hr=(\[Rho]1-\[Rho]2)/(\[Rho]1-\[Rho]3);
	(a^2+4)En+En(1/2 (\[Rho]3(\[Rho]1+\[Rho]2+\[Rho]3)-\[Rho]1 \[Rho]2+(\[Rho]1+\[Rho]2+\[Rho]3+\[Rho]4)(\[Rho]2-\[Rho]3) EllipticPi[hr,kr]/EllipticK[kr]+(\[Rho]1-\[Rho]3)(\[Rho]2-\[Rho]4) EllipticE[kr]/EllipticK[kr])+2(\[Rho]3+(\[Rho]2-\[Rho]3) EllipticPi[hr,kr]/EllipticK[kr])+1/Sqrt[1-a^2] (((4-a L/En)\[Rho]out-2a^2)/(\[Rho]3-\[Rho]out) (1-(\[Rho]2-\[Rho]3)/(\[Rho]2-\[Rho]out) EllipticPi[hout,kr]/EllipticK[kr])-((4-a L/En)\[Rho]in-2a^2)/(\[Rho]3-\[Rho]in) (1-( \[Rho]2-\[Rho]3)/(\[Rho]2-\[Rho]in) EllipticPi[hin,kr]/EllipticK[kr])))
]


KerrGeoMinoFrequencytr[a_,p_,e_/;e==1,x_,{En_,L_,Q_},{\[Rho]1_,\[Rho]2_,\[Rho]3_,\[Rho]4_}]:=\[Infinity]


KerrGeoMinoFrequencytr[a_/;a^2==1,p_,e_,x_,{En_,L_,Q_},{\[Rho]1_,\[Rho]2_,\[Rho]3_,\[Rho]4_}]:=Module[{\[Rho]in,\[Rho]out,kr,hM,hr},
	\[Rho]in= 1-Sqrt[1-a^2];\[Rho]out= 1+Sqrt[1-a^2];
	kr= (\[Rho]1-\[Rho]2)/(\[Rho]1-\[Rho]3) (\[Rho]3-\[Rho]4)/(\[Rho]2-\[Rho]4);
	hM= (\[Rho]1-\[Rho]2)/(\[Rho]1-\[Rho]3) (\[Rho]3-1)/(\[Rho]2-1);
	hr=(\[Rho]1-\[Rho]2)/(\[Rho]1-\[Rho]3);
	5En+En(1/2 ((\[Rho]3(\[Rho]1+\[Rho]2+\[Rho]3)-\[Rho]1 \[Rho]2)+(\[Rho]1+\[Rho]2+\[Rho]3+\[Rho]4)(\[Rho]2-\[Rho]3) EllipticPi[hr,kr]/EllipticK[kr]+(\[Rho]1-\[Rho]3)(\[Rho]2-\[Rho]4)  EllipticE[kr]/EllipticK[kr])+2(\[Rho]3+(\[Rho]2-\[Rho]3) EllipticPi[hr,kr]/EllipticK[kr])+(2(4-a L/En))/(\[Rho]3-1) (1-(\[Rho]2-\[Rho]3)/(\[Rho]2-1) EllipticPi[hM,kr]/EllipticK[kr])+(2-a L/En)/(\[Rho]3-1)^2 ((2-((\[Rho]1-\[Rho]3)(\[Rho]2-\[Rho]3))/((\[Rho]1-1)(\[Rho]2-1)))+((\[Rho]1-\[Rho]3)(\[Rho]2-\[Rho]4)(\[Rho]3-1))/((\[Rho]1-1)(\[Rho]2-1)(\[Rho]4-1)) EllipticE[kr]/EllipticK[kr]+(\[Rho]2-\[Rho]3)/(\[Rho]2-1) ((\[Rho]1-\[Rho]3)/(\[Rho]1-1)+(\[Rho]2-\[Rho]3)/(\[Rho]2-1)+(\[Rho]4-\[Rho]3)/(\[Rho]4-1)-4) EllipticPi[hM,kr]/EllipticK[kr]))
]


KerrGeoMinoFrequencyt\[Theta][a_,p_,e_,x_,{En_,L_,Q_},{zp_,zm_}]:=Module[{},
   (En Q)/((1-En^2) zm^2) (1- EllipticE[a^2 (1-En^2)(zm/zp)^2]/EllipticK[a^2 (1-En^2)(zm/zp)^2])-a^2 En
]


KerrGeoMinoFrequencyt\[Theta][a_,p_,e_/;e==1,x_,{En_,L_,Q_},{zp_,zm_}]:=Module[{},
   -a^2+(a^2 Q)/(2 zp^2)
]


KerrGeoMinoFrequencyt\[Theta][a_,p_,e_,x_/;x^2==1,{En_,L_,Q_},{zp_,zm_}]:=Module[{},
   -a^2En
]


(* ::Subsubsection:: *)
(*KerrGeoMinoFrequencies*)


KerrGeoMinoFrequencies[a_?Negative,p_,e_,x_]:=<|"\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(r\)]\)"->1,"\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Theta]\)]\)"->1,"\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Phi]\)]\)"->-1,"\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(t\)]\)"->1|>KerrGeoMinoFrequencies[-a,p,e,-x]


KerrGeoMinoFrequencies[a_,p_,e_?PossibleZeroQ, 1] := Module[{\[CapitalUpsilon]r, \[CapitalUpsilon]\[Phi], \[CapitalUpsilon]\[Theta], \[CapitalGamma]},

\[CapitalUpsilon]r = Sqrt[(p (-2 a^2+6 a Sqrt[p]+(-5+p) p+((a-Sqrt[p])^2 (a^2-4 a Sqrt[p]-(-4+p) p))/Abs[a^2-4 a Sqrt[p]-(-4+p) p]))/(2 a Sqrt[p]+(-3+p) p)];
\[CapitalUpsilon]\[Theta] = Abs[(p^(1/4) Sqrt[3 a^2-4 a Sqrt[p]+p^2])/Sqrt[2 a+(-3+p) Sqrt[p]]];
\[CapitalUpsilon]\[Phi] = p^(5/4)/Sqrt[2 a+(-3+p) Sqrt[p]];
\[CapitalGamma] = (p^(5/4) (a+p^(3/2)))/Sqrt[2 a+(-3+p) Sqrt[p]];

 <| "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(r\)]\)" -> \[CapitalUpsilon]r,
    "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Theta]\)]\)" -> Abs[\[CapitalUpsilon]\[Theta]],
    "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Phi]\)]\)" -> \[CapitalUpsilon]\[Phi],
    "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(t\)]\)" -> \[CapitalGamma] |>

]


KerrGeoMinoFrequencies[a_,p_,e_,x_,Qc_]:=Module[{En,L,Q,r1,r2,r3,r4,zm,zp,\[CapitalUpsilon]r,\[CapitalUpsilon]\[Theta],\[CapitalUpsilon]\[Phi],\[CapitalUpsilon]t},
{En,L,Q} = Values[KerrGeoConstantsOfMotionN[a,p,e,Qc]];
{r1,r2,r3,r4} = KerrGeoRadialRoots[a,p,e,x,Qc];
{zp,zm}=KerrGeoPolarRoots[a,p,e,x,Qc];
\[CapitalUpsilon]r= KerrGeoMinoFrequencyr[a,p,e,x,{En,L,Q},{r1,r2,r3,r4}];
\[CapitalUpsilon]\[Theta]= KerrGeoMinoFrequency\[Theta][a,p,e,x,{En,L,Q},{zp,zm}];
\[CapitalUpsilon]\[Phi]= KerrGeoMinoFrequency\[Phi][a,p,e,x,{En,L,Q},{r1,r2,r3,r4},{zp,zm}];
\[CapitalUpsilon]t= KerrGeoMinoFrequencyt[a,p,e,x,{En,L,Q},{r1,r2,r3,r4},{zp,zm}];

 <| "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(r\)]\)" -> \[CapitalUpsilon]r,
    "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Theta]\)]\)" -> Abs[\[CapitalUpsilon]\[Theta]],
    "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Phi]\)]\)" -> \[CapitalUpsilon]\[Phi],
    "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(t\)]\)" -> \[CapitalUpsilon]t |>

]


KerrGeoBoyerLindquistFrequencies[a_,p_,e_,x_,Qc_]:=Module[{\[CapitalUpsilon]r,\[CapitalUpsilon]\[Theta],\[CapitalUpsilon]\[Phi],\[CapitalGamma]},

{\[CapitalUpsilon]r,\[CapitalUpsilon]\[Theta],\[CapitalUpsilon]\[Phi],\[CapitalGamma]} = Values[KerrGeoMinoFrequencies[a,p,e,x,Qc]];

  <| "\!\(\*SubscriptBox[\(\[CapitalOmega]\), \(r\)]\)" -> \[CapitalUpsilon]r,
     "\!\(\*SubscriptBox[\(\[CapitalOmega]\), \(\[Theta]\)]\)" -> \[CapitalUpsilon]\[Theta],
     "\!\(\*SubscriptBox[\(\[CapitalOmega]\), \(\[Phi]\)]\)" -> \[CapitalUpsilon]\[Phi] 
   |>/\[CapitalGamma]
]


KerrGeoBoyerLindquistFrequencies[a_,p_,e_/;e>1,x_]:=Module[{},
    <| "\!\(\*SubscriptBox[\(\[CapitalOmega]\), \(r\)]\)" -> 0,
     "\!\(\*SubscriptBox[\(\[CapitalOmega]\), \(\[Theta]\)]\)" -> 0,
     "\!\(\*SubscriptBox[\(\[CapitalOmega]\), \(\[Phi]\)]\)" -> 0 
   |> 
]


KerrGeoProperFrequencyFactor[a_,p_,e_,x_]:=Module[{\[Rho]1,\[Rho]2,\[Rho]3,\[Rho]4,zm,zp,T},
	{\[Rho]1,\[Rho]2,\[Rho]3,\[Rho]4}=KerrGeoRadialRoots[a,p,e,x];
	{zp,zm}=KerrGeoPolarRoots[a,p,e,x];
	T=KerrGeoEnergy[a,p,e,x];
	With[{kr= (\[Rho]1-\[Rho]2)/(\[Rho]1-\[Rho]3) (\[Rho]3-\[Rho]4)/(\[Rho]2-\[Rho]4), k\[Theta]=a^2 (1-T^2)(zm/zp)^2, hr=(\[Rho]1-\[Rho]2)/(\[Rho]1-\[Rho]3)},

		1/2 (-((2 zp^2)/(-1+T^2))+\[Rho]1 (-\[Rho]2+\[Rho]3)+\[Rho]3 (\[Rho]2+\[Rho]3))
		+((\[Rho]1-\[Rho]3) (\[Rho]2-\[Rho]4) EllipticE[kr])/(2 EllipticK[kr])
		+(zp^2 EllipticE[k\[Theta]])/((-1+T^2) EllipticK[k\[Theta]])+((\[Rho]2-\[Rho]3) (\[Rho]1+\[Rho]2+\[Rho]3+\[Rho]4) EllipticPi[hr,kr])/(2 EllipticK[kr])
	]
]


KerrGeoProperFrequencyFactor[a_,p_,e_/;e>=1,x_]:=\[Infinity]

KerrGeoProperFrequencies[a_,p_,e_,x_]:=Module[{MinoFreqs,P},
	MinoFreqs = KerrGeoMinoFrequencies[a,p,e,x];
	P=KerrGeoProperFrequencyFactor[a,p,e,x];
	<|"\!\(\*SubscriptBox[\(\[Omega]\), \(r\)]\)"-> MinoFreqs["\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(r\)]\)"]/P, "\!\(\*SubscriptBox[\(\[Omega]\), \(\[Theta]\)]\)"-> MinoFreqs["\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Theta]\)]\)"]/P, "\!\(\*SubscriptBox[\(\[Omega]\), \(\[Phi]\)]\)"-> MinoFreqs["\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Phi]\)]\)"]/P |>
]


KerrGeoProperFrequencies[a_,p_,e_/;e==1,x_]:=Module[{MinoFreqs,P},
	<|"\!\(\*SubscriptBox[\(\[Omega]\), \(r\)]\)"-> 0, "\!\(\*SubscriptBox[\(\[Omega]\), \(\[Theta]\)]\)"-> 0, "\!\(\*SubscriptBox[\(\[Omega]\), \(\[Phi]\)]\)"-> 0 |>
]


(* ::Subsection:: *)
(*Generic function for choosing between frequencies w.r.t different time coordinates*)


Options[KerrGeoFrequencies] = {"Time" -> "BoyerLindquist"};
SyntaxInformation[KerrGeoFrequencies] = {"ArgumentsPattern"->{_,_,_,_,OptionsPattern[]}};
KerrGeoFrequencies[a_,p_,e_,x_,Qc_,OptionsPattern[]] := Module[{M=1,En,L,Q,r1,r2,r3,r4,\[Epsilon]0,zm,a2zp,\[Epsilon]0zp,zmOverZp,kr,k\[Theta],\[CapitalUpsilon]r,\[CapitalUpsilon]\[Theta],rp,rm,hr,hp,hm,\[CapitalUpsilon]\[Phi],\[CapitalGamma]},


If[OptionValue["Time"]=="Mino",Return[KerrGeoMinoFrequencies[a,p,e,x,Qc][[1;;4]]]];

If[OptionValue["Time"]=="BoyerLindquist", Return[KerrGeoBoyerLindquistFrequencies[a,p,e,x,Qc]]];

If[OptionValue["Time"]=="Proper",Return[KerrGeoProperFrequencies[a,p,e,x,Qc][[1;;3]]]];

]


(* ::Section:: *)
(*KNGeoOrbits*)


(*t and \[Phi] accumulated over one orbit*)
\[CapitalPhi]SchwarzDarwin[p_,e_]:=4 Sqrt[p/(p-6+2e)] EllipticK[(4 e)/(p-6+2e)]
TSchwarzDarwin[p_,e_]:=(2p Sqrt[(p-6+2e)((p-2)^2-4e^2)])/((1-e^2)(p-4)) EllipticE[(4e)/(p-6+2e)]-2p Sqrt[(p-2)^2-4e^2]/((1-e^2)Sqrt[p-6+2e]) EllipticK[(4e)/(p-6+2e)]-(4(8(1-e^2)+p(1+3e^2-p))Sqrt[(p-2)^2-4e^2])/((1-e)(1-e^2)(p-4)Sqrt[p-6+2e]) EllipticPi[-((2e)/(1-e)),(4e)/(p-6+2e)]+(16Sqrt[(p-2)^2-4e^2])/((p-2+2e)Sqrt[p-6+2e]) EllipticPi[(4e)/(p-2+2e),(4e)/(p-6+2e)]


tSchwarzDarwin[p_,e_/;e<1,\[Xi]_]:=TSchwarzDarwin[p,e]/2+((p Sqrt[(p-6+2e)((p-2)^2-4e^2)])/((1-e^2)(p-4)) EllipticE[\[Xi]/2-\[Pi]/2,(4e)/(p-6+2e)]-p Sqrt[(p-2)^2-4e^2]/((1-e^2)Sqrt[p-6+2e]) EllipticF[\[Xi]/2-\[Pi]/2,(4e)/(p-6+2e)]-(2(8(1-e^2)+p(1+3e^2-p))Sqrt[(p-2)^2-4e^2])/((1-e)(1-e^2)(p-4)Sqrt[p-6+2e]) EllipticPi[-((2e)/(1-e)),\[Xi]/2-\[Pi]/2,(4e)/(p-6+2e)]+(8Sqrt[(p-2)^2-4e^2])/((p-2+2e)Sqrt[p-6+2e]) EllipticPi[(4e)/(p-2+2e),\[Xi]/2-\[Pi]/2,(4e)/(p-6+2e)]-e p Sqrt[((p-2)^2-4e^2)(p-6-2e Cos[\[Xi]])]/((1-e^2)(p-4)(1+e Cos[\[Xi]])) Sin[\[Xi]])
rSchwarzDarwin[p_,e_/;e<1,\[Chi]_]:=p/(1 + e Cos[\[Chi]])
\[Theta]SchwarzDarwin[p_,e_,\[Chi]_]:= \[Pi]/2 
\[Phi]SchwarzDarwin[p_,e_/;e<1,\[Xi]_]:=\[CapitalPhi]SchwarzDarwin[p,e]/2+2Sqrt[p/(p-6+2e)]EllipticF[\[Xi]/2-\[Pi]/2,(4 e)/(p-6+2e)]


tSchwarzDarwin[p_/;p>6, 0, \[Xi]_] := ((p^2) \[Xi] )/Sqrt[-6+p] 
rSchwarzDarwin[p_/;p>6, 0, \[Xi]_] := p;
\[Phi]SchwarzDarwin[p_/;p>6, 0, \[Xi]_] := Sqrt[p/(-6+p)] \[Xi]


(*defined such that t=\[Phi]=0 at periastron*)
tSchwarzDarwin[p_, e_/;e>1, \[Chi]_] /; Abs[\[Chi]]<ArcCos[-1/e] := (I Sqrt[-4e^2+(-2+p)^2]p Sqrt[-6+2e+p] EllipticE[I ArcSinh[Sqrt[-6-2e+p]/Sqrt[6+2e-p]],(-6-2e+p)/(-6+2e+p)])/((-1+e)(1+e)(-4+p))+(Sqrt[-4e^2+(-2+p)^2]p Sqrt[-6+2e+p]Sqrt[-1+Cos[\[Chi]]]Sqrt[1+Cos[\[Chi]]]Csc[\[Chi]] EllipticE[I ArcSinh[Sqrt[-6+p-2e Cos[\[Chi]]]/Sqrt[6+2e-p]],(-6-2e+p)/(-6+2e+p)])/((-1+e)(1+e)(-4+p))-((2I)Sqrt[-4e^2+(-2+p)^2]p EllipticF[I ArcSinh[Sqrt[-6-2e+p]/Sqrt[6+2e-p]],(-6-2e+p)/(-6+2e+p)])/((1+e)(-4+p)Sqrt[-6+2e+p])-(2Sqrt[-4e^2+(-2+p)^2]p Sqrt[-1+Cos[\[Chi]]]Sqrt[1+Cos[\[Chi]]]Csc[\[Chi]] EllipticF[I ArcSinh[Sqrt[-6+p-2e Cos[\[Chi]]]/Sqrt[6+2e-p]],(-6-2e+p)/(-6+2e+p)])/((1+e)(-4+p)Sqrt[-6+2e+p])+((2I)Sqrt[-4e^2+(-2+p)^2] EllipticPi[(6+2e-p)/4,I ArcSinh[Sqrt[-6-2e+p]/Sqrt[6+2e-p]],(-6-2e+p)/(-6+2e+p)])/Sqrt[-6+2e+p]+(2Sqrt[-4e^2+(-2+p)^2]Sqrt[-1+Cos[\[Chi]]]Sqrt[1+Cos[\[Chi]]]Csc[\[Chi]] EllipticPi[(6+2e-p)/4,I ArcSinh[Sqrt[-6+p-2e*Cos[\[Chi]]]/Sqrt[6+2e-p]],(-6-2e+p)/(-6+2e+p)])/Sqrt[-6+2e+p]+((4I)Sqrt[-4e^2+(-2+p)^2](8+p-p^2+e^2(-8+3p)) EllipticPi[(-6-2e+p)/(-4+p),I ArcSinh[Sqrt[-6-2e+p]/Sqrt[6+2e-p]],(-6-2e+p)/(-6+2e+p)])/((-1+e^2)(-4+p)^2Sqrt[-6+2e+p])+(4Sqrt[-4e^2+(-2+p)^2](8+p-p^2+e^2(-8+3p))Sqrt[-1+Cos[\[Chi]]]Sqrt[1+Cos[\[Chi]]]Csc[\[Chi]] EllipticPi[(-6-2e+p)/(-4+p),I ArcSinh[Sqrt[-6+p-2e*Cos[\[Chi]]]/Sqrt[6+2e-p]],(-6-2e+p)/(-6+2e+p)])/((-1+e^2)(-4+p)^2Sqrt[-6+2e+p])+(e Sqrt[-4e^2+(-2+p)^2] p Sqrt[-6+p-2e Cos[\[Chi]]]Sin[\[Chi]])/((-1+e)(1+e)(-4+p)(1+e Cos[\[Chi]]))//Re
tSchwarzDarwin[p_, e_/;e>1, \[Chi]_] /; Abs[\[Chi]]==ArcCos[-1/e] := Sign[\[Chi]] Infinity
rSchwarzDarwin[p_, e_/;e>1, \[Chi]_] /; Abs[\[Chi]]<ArcCos[-1/e] :=p/(1 + e Cos[\[Chi]])
\[Phi]SchwarzDarwin[p_, e_/;e>1, \[Chi]_] /; Abs[\[Chi]]<=ArcCos[-1/e] := 2 Sqrt[p] EllipticF[\[Chi]/2,(4e)/(6+2e-p)]/Sqrt[-6-2e+p]


tSchwarzDarwin[p_, e_/;e>1, \[Chi]_] /; Abs[\[Chi]]>ArcCos[-1/e] := Message[KerrGeoOrbit::OutOfBounds, -ArcCos[-1/e], ArcCos[-1/e]];
rSchwarzDarwin[p_, e_/;e>1, \[Chi]_] /; Abs[\[Chi]]>ArcCos[-1/e] := Message[KerrGeoOrbit::OutOfBounds, -ArcCos[-1/e], ArcCos[-1/e]];
\[Phi]SchwarzDarwin[p_, e_/;e>1, \[Chi]_] /; Abs[\[Chi]]>ArcCos[-1/e] := Message[KerrGeoOrbit::OutOfBounds, -ArcCos[-1/e], ArcCos[-1/e]];


DarwinBounds[e_/;0<=e<1]:= {-\[Infinity], \[Infinity]}
DarwinBounds[e_/;e>=1]:= { -ArcCos[-1/e], ArcCos[-1/e] }


KerrGeoOrbitSchwarzDarwin[p_, e_] := Module[{t, r, \[Theta], \[Phi], assoc, consts, En, L,Q, type, \[Chi]Bounds, velocity, paramRange},
t = Function[{Global`\[Chi]}, Evaluate[ tSchwarzDarwin[p,e,Global`\[Chi]] ], Listable];
r = Function[{Global`\[Chi]}, Evaluate[ rSchwarzDarwin[p,e,Global`\[Chi]] ], Listable];
\[Theta] = Function[{Global`\[Chi]}, Evaluate[ \[Theta]SchwarzDarwin[p,e,Global`\[Chi]] ], Listable];
\[Phi] = Function[{Global`\[Chi]}, Evaluate[ \[Phi]SchwarzDarwin[p,e,Global`\[Chi]] ], Listable];

consts = KerrGeoConstantsOfMotion[0,p,e,1];
{En,L,Q} = {"\[ScriptCapitalE]","\[ScriptCapitalL]","\[ScriptCapitalQ]"}/.consts;
type = KerrGeoOrbitType[0,p,e,1];
velocity = Values[KerrGeoFourVelocity[0,p,e,1,"Parametrization"->"Darwin"]];
paramRange = DarwinBounds[e];

assoc = Association[
			"Trajectory" -> {t,r,\[Theta],\[Phi]},
			"FourVelocity"-> velocity,
			"Parametrization" -> "Darwin", 
			"ConstantsOfMotion"-> consts, 
			"Frequencies"->KerrGeoFrequencies[0,p,e,1],
			"a" -> 0,
			"p" -> p,
			"e" -> e,
			"Inclination" -> 1,
			"Energy" -> En,
			"AngularMomentum" -> L,
			"CarterConstant" -> Q,
			"Periastron" -> p/(1+e),
			"Type" -> type,
			"ParameterRange" -> paramRange
			];

KerrGeoOrbitFunction[0, p, e, 1, assoc]
]


(* ::Section:: *)
(*Kerr*)


(* ::Subsection:: *)
(*Equatorial (Darwin)*)


KerrGeoOrbitEquatorialDarwin[a_,p_,e_,x_/;x^2==1, Qc_,initPhases:{_,_,_,_}:{0,0,0,0}] := Module[{orbitMino,freqs,r1,r2,r3,r4,\[CapitalLambda]r,yr,kr,\[Lambda]0r,r,r01,\[CapitalLambda]r1,\[Lambda],consts,En,L,Q,tMino,rMino,\[Theta]Mino,\[Phi]Mino,tDarwin,rDarwin,\[Theta]Darwin,\[Phi]Darwin,assoc,velocity,type},

orbitMino = KerrGeoOrbit[a,p,e,x,Qc,initPhases];

{r1,r2,r3,r4} = orbitMino["RadialRoots"];
freqs = orbitMino["Frequencies"];
consts = orbitMino["ConstantsOfMotion"];
{En,L,Q} = Values[consts];
\[CapitalLambda]r = (2\[Pi])/freqs[[1]];

If[
PossibleZeroQ[e],
yr[r_]:=1
,
yr[r_]:=Sqrt[(r1-r3)/(r1-r2) (r-r2)/(r-r3)]
];
kr=(r1-r2)/(r1-r3) (r3-r4)/(r2-r4);
\[Lambda]0r[r_]:=1/Sqrt[1-En^2] 2/Sqrt[(r1-r3)(r2-r4)] EllipticF[ArcSin[yr[r]],kr];


r[\[Chi]_]:=p/(1+e Cos[\[Chi]]);

r01=r2;
\[CapitalLambda]r1=\[Lambda]0r[r01];


If[
PossibleZeroQ[e],
\[Lambda][\[Chi]_]:=\[CapitalLambda]r \[Chi]/(2\[Pi])
,
\[Lambda][\[Chi]_]:=\[CapitalLambda]r Floor[\[Chi]/(2\[Pi])]+Piecewise[{{\[Lambda]0r[r[\[Chi]]]-\[CapitalLambda]r1,Mod[\[Chi],2\[Pi]]<=\[Pi]}} , \[CapitalLambda]r-\[Lambda]0r[r[\[Chi]]] ]
];
{tMino, rMino, \[Theta]Mino, \[Phi]Mino} = orbitMino["Trajectory"];

tDarwin=Function[{Global`\[Chi]}, Evaluate[ tMino[\[Lambda][Global`\[Chi]]] ], Listable];
rDarwin=Function[{Global`\[Chi]}, Evaluate[ rMino[\[Lambda][Global`\[Chi]]] ], Listable];
\[Theta]Darwin=Function[{Global`\[Chi]}, Evaluate[ \[Theta]Mino[\[Lambda][Global`\[Chi]]] ], Listable];
\[Phi]Darwin=Function[{Global`\[Chi]}, Evaluate[ \[Phi]Mino[\[Lambda][Global`\[Chi]]] ], Listable];

velocity = Values[KerrGeoFourVelocity[a,p,e,x,Qc,{initPhases[[2]],initPhases[[3]]},"Parametrization"->"Darwin"]];

type = KerrGeoOrbitType[a,p,e,x];

assoc = Association[
			"Trajectory" -> {tDarwin,rDarwin,\[Theta]Darwin,\[Phi]Darwin}, 
			"FourVelocity"-> velocity,
			"Parametrization" -> "Darwin", 
			"ConstantsOfMotion"-> consts, 
			"Frequencies" -> freqs,
			"RadialRoots"->{r1,r2,r3,r4},
			"a" -> a,
			"p" -> p,
			"e" -> e,
			"Inclination" -> x,
			"Energy" -> En,
			"AngularMomentum" -> L,
			"CarterConstant" -> Q,
			"Type" -> type,
			"InitialPhases" -> initPhases
		];

KerrGeoOrbitFunction[a, p, e, x, assoc]

]



(* ::Subsection:: *)
(*Equatorial (Fast Spec - Darwin)*)


(* ::Subsubsection:: *)
(*Subroutines that checks for the number of samples necessary for spectral integration*)


Clear[DarwinFastSpecIntegrateAndConvergenceCheck];
DarwinFastSpecIntegrateAndConvergenceCheck[func_]:=
Module[{test,compare,res,NInit,iter=1,sampledFunc,phaseList,pg,eps,coeffs,
	coeffsList,coeffsN,\[CapitalDelta]integratedFunc,growthRate,fn,nIter,sampleMax},
	(*DarwinFastSpecIntegrateAndConvergenceCheck takes a function 'func' and integrates
	'func' with respect to the Darwin parameter \[Chi] using spectral methods:
				-- func: a function that takes an integer 'N' as an argument and returns
						 function values at N points. These points are sampled at evenly
						 spaced values of the Darwin parameter \[Chi]  *)
	
	(* Memoize function that we are integrating with respect to the Darwin parameter *)
	sampledFunc[NN_]:=sampledFunc[NN]=func[NN];
	(* Determine precision of sampled points. 
	Use precision to check for convergence of spectral methods *)
	pg=Precision[sampledFunc[16][[2]]];

	(* Use Mathematica's built in DCT solver to determine DCT coefficients *)
	coeffs[Nr_]:=coeffs[Nr]=FourierDCT[sampledFunc[Nr],1]Sqrt[2/(Nr-1)]/.var_?NumericQ/;var==0:>0;
	(* Find the relative accuracy of the DCT coefficients by comparing the last two 
	DCT coefficients to the n=0 coefficient *)
	res[Nr_]:=Min[Abs@RealExponent[coeffs[Nr][[-1]]/coeffs[Nr][[1]]],Abs@RealExponent[coeffs[Nr][[-2]]/coeffs[Nr][[1]]]];

	(* Treat machine precision calculations differently from arbitrary precision *)
	If[pg==$MachinePrecision,
		(* eps sets the precision goal/numerical tolerance for our solutions *)
		eps=15;
		(* Set some initial value of sample points *)
		NInit=2^4;
		(* Find number of sample points necessary to match precision goal 'eps' *)
		While[res[NInit]<eps&&iter<20,NInit=2*NInit;iter++]
		,
		(* Set initial value of sample points at slightly larger value for extended precision calculations *)
		NInit=2^5;
		(* Also test for convergence by increasing the sample size until the n=0 coefficient is unchanged *)
		compare=coeffs[NInit/2][[1]]; (*n=0 coefficient *)
		While[((compare =!= (compare = coeffs[NInit][[1]]))||res[NInit]<pg+1)&&iter<20,NInit=2*NInit; iter++]
	];
	(* After determining the number of sampled points necessary for convergence, store DCT coefficients *)
	coeffsList=coeffs[NInit];
	fn[n_]:=fn[n]=coeffsList[[n+1]];
	growthRate=coeffsList[[1]]/2;
	(* Evaluate new weighted coefficients due to integrating the interpolated inverse DCT transformation *)
	If[pg==MachinePrecision,
		coeffsN[NInit-1]=fn[NInit-1]/(NInit-1);
		nIter=2^2+2;
		Do[coeffsN[n]=coeffsList[[n+1]]/n,{n,1,nIter-2}];
		eps=15-RealExponent[Sum[Abs[fn[n]],{n,0,nIter-2}]];
		While[(-RealExponent[fn[nIter]]<=eps||-RealExponent[fn[nIter-1]]<=eps)&&nIter<NInit-2,coeffsN[nIter]=fn[nIter]/nIter;coeffsN[nIter-1]=fn[nIter-1]/(nIter-1);nIter+=2];
		coeffsN[nIter]=fn[nIter]/nIter;
		coeffsN[nIter-1]=fn[nIter-1]/(nIter-1);
		sampleMax=Min[nIter,NInit-2],
		Do[coeffsN[n]=coeffsList[[n+1]]/n,{n,1,NInit-1}];
		sampleMax=NInit-2;
	];
	(* Construct integrated series solution *)
	\[CapitalDelta]integratedFunc[\[Chi]_]:=coeffsN[NInit-1]/2 Sin[(NInit-1)*\[Chi]]+Sum[coeffsN[nIter] Sin[nIter \[Chi]],{nIter,1,sampleMax}];
	(* Allow function to evaluate lists by threading over them *)
	(* Return the linear rate of growth and the oscillatory function \[CapitalDelta]integratedFunc *)
	{growthRate,\[CapitalDelta]integratedFunc}
];


(* ::Subsubsection:: *)
(*Main file that calculates geodesics using spectral integration*)


Clear[KerrGeoOrbitFastSpecDarwin];
KerrGeoOrbitFastSpecDarwin[a_,p_,e_,x_/;x^2==1,Qc_,initPhases:{_,_,_,_}:{0,0,0,0}]:=
Module[{M=1,consts,En,L,Q,r1,r2,r3,r4,p3,p4,assoc,var,t0, \[Chi]0, \[Phi]0,r0,\[Theta]0,t,r,\[Theta],\[Phi],\[Chi],growthRateT,growthRatePh,
		\[Chi]r,NrMax,pg,\[CapitalDelta]tr,\[CapitalDelta]\[Phi]r,\[Phi]C,tC,Pr,r0Sample,PrSample,dtd\[Chi],d\[Phi]d\[Chi],TVr,PVr,velocities,type},
	consts = KerrGeoConstantsOfMotionN[a,p,e,Qc];
	{En,L,Q} = Values[consts];
	{r1,r2,r3,r4} = KerrGeodesics`OrbitalFrequencies`Private`KerrGeoRadialRoots[a, p, e, x, En, Q];
	p3=(1-e)r3/M;
	p4=(1+e)r4/M;
	
	(*Precision of sampling depends on precision of arguments*)
	pg=Min[{Precision[{a,p,e,x}],Precision[initPhases]}];
	
	(*Parameterize r in terms of Darwin parameter \[Chi]*)
	r0[chi_]:=p M/(1+e Cos[chi]);
	\[Theta]0[chi_]:=N[Pi/2,pg];
	
	(* Expressions for dt/d\[Lambda] = TVr and d\[Phi]/d\[Lambda] = PVr *)
	TVr[rp_]:=(En*(a^2 + rp^2)^2)/(a^2 - 2*M*rp + rp^2) + a*L*(1 - (a^2 + rp^2)/(a^2 - 2*M*rp + rp^2))-a^2*En;
	PVr[rp_]:=-((a^2*L)/(a^2 - 2*M*rp + rp^2)) + a*En*(-1 + (a^2 + rp^2)/(a^2 - 2*M*rp + rp^2))+L;
	
	(* Sampling of radial position using evenly spaced values of Darwin parameter \[Chi]*)
	If[pg==$MachinePrecision,
		\[Chi]r[Nr_]:=N[Table[i Pi/(Nr-1),{i,0,Nr-1}]],
		\[Chi]r[Nr_]:=N[Table[i Pi/(Nr-1),{i,0,Nr-1}],1.5pg]
	];
	r0Sample[Nr_]:=r0[\[Chi]r[Nr]];
	
	(* Expression for d\[Lambda]/d\[Chi]*)
	Pr[chi_]:=(1-e^2)/Sqrt[(p-p4)+e(p-p4 Cos[chi])]/(M (1-En^2)^(1/2)Sqrt[(p-p3)-e(p+p3 Cos[chi])]);
	PrSample[Nr_]:=Pr[\[Chi]r[Nr]];
	
	(* Sampling of expressions for dt/d\[Chi] and d\[Phi]/d\[Chi] *)
	dtd\[Chi][Nr_]:=TVr[r0Sample[Nr]]PrSample[Nr];
	d\[Phi]d\[Chi][Nr_]:=PVr[r0Sample[Nr]]PrSample[Nr];
	
	(*Spectral integration of t and \[Phi] as functions of \[Chi]*)
	{growthRateT,\[CapitalDelta]tr}=DarwinFastSpecIntegrateAndConvergenceCheck[dtd\[Chi]];
	{growthRatePh,\[CapitalDelta]\[Phi]r}=DarwinFastSpecIntegrateAndConvergenceCheck[d\[Phi]d\[Chi]];
	
	(*Collect initial phases*)
	{t0, \[Chi]0, \[Phi]0} = {initPhases[[1]], initPhases[[2]], initPhases[[4]]};
	(* Find integration constants for t and \[Phi], so that t(\[Chi]=0)=t0 and \[Phi](\[Chi]=0)=\[Phi]0 *)
	\[Phi]C=\[CapitalDelta]\[Phi]r[\[Chi]0];
	tC=\[CapitalDelta]tr[\[Chi]0];
	
	t=Function[{Global`\[Chi]}, Evaluate[ \[CapitalDelta]tr[Global`\[Chi]+\[Chi]0]+growthRateT Global`\[Chi]+t0-tC ], Listable];
	r=Function[{Global`\[Chi]}, Evaluate[ r0[Global`\[Chi]+\[Chi]0] ] , Listable];
	\[Theta]=Function[{Global`\[Chi]}, Evaluate[ \[Theta]0[Global`\[Chi]] ], Listable];
	\[Phi]=Function[{Global`\[Chi]}, Evaluate[ \[CapitalDelta]\[Phi]r[Global`\[Chi]+\[Chi]0]+growthRatePh Global`\[Chi]+\[Phi]0-\[Phi]C ], Listable];
	
	velocities = Values[KerrGeoFourVelocity[a,p,e,x,Qc,{initPhases[[2]],initPhases[[3]]}, "Parametrization"-> "Darwin"]];
	
	type = KerrGeoOrbitType[a,p,e,x];
	
	assoc = Association[
		"Parametrization"->"Darwin",
		"Energy" -> En, 
		"AngularMomentum" -> L, 
		"CarterConstant" -> Q, 
		"ConstantsOfMotion" -> consts,
		"Trajectory" -> {t,r,\[Theta],\[Phi]},
		"FourVelocity"-> velocities,
		"RadialRoots" -> {r1,r2,r3,r4},
		"Frequencies" -> KerrGeoFrequencies[a,p,e,x],
		"a" -> a,
		"p" -> p,
		"e" -> e,
		"Inclination" -> x,
		"Qc" -> Qc,
		"Type" -> type,
		"InitialPhases" -> initPhases
		];
	
	KerrGeoOrbitFunction[a,p,e,x,assoc]
]


(* ::Subsection:: *)
(*Circular (Fast Spec - Darwin)*)


(* ::Subsubsection:: *)
(*Main file that calculates geodesics using spectral integration*)


KerrGeoOrbitFastSpecDarwin[a_,p_,e_/;e==0,x_,Qc_,initPhases:{_,_,_,_}:{0,0,0,0}]:=
Module[{M=1,consts,En,L,Q,zp,zm,assoc,var,t0, \[Chi]0, \[Phi]0,r0,\[Theta]0,t,r,\[Theta],\[Phi],\[Chi],freqT,freqPh,
		\[Chi]\[Theta],pg,\[CapitalDelta]t\[Theta],\[CapitalDelta]\[Phi]\[Theta],\[Phi]C,tC,P\[Theta],\[Theta]0Sample,P\[Theta]Sample,dtd\[Chi],d\[Phi]d\[Chi],TV\[Theta],PV\[Theta],\[Beta],\[Alpha],zRoots,radialRoots,velocity,type},
	consts = KerrGeoConstantsOfMotionN[a,p,e,Qc];
	{En,L,Q} = Values[consts];
	radialRoots = KerrGeoRadialRoots[a,p,e,x,Qc];
	
	(* Useful constants for \[Theta]-dependent calculations *)
	\[Beta]=a^2(1-En^2);
	\[Alpha]=L^2+Q+\[Beta];
	zp=Sqrt[(\[Alpha]+Sqrt[\[Alpha]^2-4 Q \[Beta]])/(2\[Beta])];
	zm=Sqrt[(\[Alpha]-Sqrt[\[Alpha]^2-4 Q \[Beta]])/(2\[Beta])];
	zRoots={ArcCos[zm],Pi-ArcCos[zm]};
	
	(*Precision of sampling depends on precision of arguments*)
	pg=Min[{Precision[{a,p,e,x}],Precision[initPhases]}];
	
	(*Parameterize \[Theta] in terms of Darwin-like parameter \[Chi]*)
	r0[chi_]:=N[p M,pg];

	\[Theta]0[chi_]:=ArcCos[zm Cos[chi]];

	(* Expressions for dt/d\[Lambda] = TV\[Theta] and d\[Phi]/d\[Lambda] = PV\[Theta] *)
	TV\[Theta][\[Theta]p_]:=(En*(a^2 + M^2 p^2)^2)/(a^2 - 2*M^2*p + M^2p^2) + a*L*(1 - (a^2 + p^2)/(a^2 - 2*M^2*p + M^2 p^2))-a^2*En Sin[\[Theta]p]^2;
	PV\[Theta][\[Theta]p_]:=-((a^2*L)/(a^2 - 2*M^2*p + M^2p^2)) + a*En*(-1 + (a^2 + M^2p^2)/(a^2 - 2*M^2*p + M^2p^2))+L Csc[\[Theta]p]^2;
	
	(* Sampling of radial position using evenly spaced values of Darwin parameter \[Chi]*)
	If[pg==$MachinePrecision,
		\[Chi]\[Theta][Nth_]:=N[Table[i Pi/(Nth-1),{i,0,Nth-1}]],
		\[Chi]\[Theta][Nth_]:=N[Table[i Pi/(Nth-1),{i,0,Nth-1}],1.5pg]
	];
	\[Theta]0Sample[Nth_]:=\[Theta]0[\[Chi]\[Theta][Nth]];
	
	(* Expression for d\[Lambda]/d\[Chi]*)
	P\[Theta][chi_]:=(\[Beta](zp^2-zm^2 Cos[chi]^2))^(-1/2);
	P\[Theta]Sample[Nth_]:=P\[Theta][\[Chi]\[Theta][Nth]];
	
	(* Sampling of expressions for dt/d\[Chi] and d\[Phi]/d\[Chi] *)
	dtd\[Chi][Nr_]:=TV\[Theta][\[Theta]0Sample[Nr]]P\[Theta]Sample[Nr];
	d\[Phi]d\[Chi][Nr_]:=PV\[Theta][\[Theta]0Sample[Nr]]P\[Theta]Sample[Nr];

	(*Spectral integration of t and \[Phi] as functions of \[Chi]*)
	{freqT,\[CapitalDelta]t\[Theta]}=DarwinFastSpecIntegrateAndConvergenceCheck[dtd\[Chi]];
	{freqPh,\[CapitalDelta]\[Phi]\[Theta]}=DarwinFastSpecIntegrateAndConvergenceCheck[d\[Phi]d\[Chi]];
	
	(*Collect initial phases*)
	{t0, \[Chi]0, \[Phi]0} = {initPhases[[1]], initPhases[[3]], initPhases[[4]]};
	(* Find integration constants for t and \[Phi], so that t(\[Chi]=0)=t0 and \[Phi](\[Chi]=0)=\[Phi]0 *)
	\[Phi]C=\[CapitalDelta]\[Phi]\[Theta][\[Chi]0];
	tC=\[CapitalDelta]t\[Theta][\[Chi]0];
	
	t =Function[{Global`\[Chi]}, Evaluate[ (*\[CapitalDelta]t\[Theta][Global`\[Chi]+\[Chi]0]+*)freqT Global`\[Chi]+t0-tC ], Listable];
	r =Function[{Global`\[Chi]}, Evaluate[ r0[Global`\[Chi]] ], Listable];
	\[Theta] =Function[{Global`\[Chi]}, Evaluate[ \[Theta]0[Global`\[Chi]+\[Chi]0] ], Listable];
	\[Phi] =Function[{Global`\[Chi]}, Evaluate[ (*\[CapitalDelta]\[Phi]\[Theta][Global`\[Chi]+\[Chi]0]+*)freqPh Global`\[Chi]+\[Phi]0-\[Phi]C ], Listable];
	
	velocity = Values[KerrGeoFourVelocity[a,p,e,x,Qc,{initPhases[[2]],initPhases[[3]]},"Parametrization"->"Darwin"]];
	
	type = KerrGeoOrbitType[a,p,e,x];
	
	assoc = Association[
		"Parametrization"->"Darwin",
		"Energy" -> En, 
		"AngularMomentum" -> L, 
		"CarterConstant" -> Q, 
		"ConstantsOfMotion" -> consts,
		"Trajectory" -> {t,r,\[Theta],\[Phi]},
		"FourVelocity"-> velocity,
		"PolarRoots" -> zRoots,
		"RadialRoots"-> radialRoots,
		"a" -> a,
		"p" -> p,
		"e" -> e,
		"Inclination" -> x,
		"Type" -> type,
		"InitialPhases" -> initPhases
		];
	
	KerrGeoOrbitFunction[a,p,e,x,assoc]
]


(* ::Subsection:: *)
(*Circular (Mino)*)


KerrGeoOrbitMino[a_, p_, (0|0.), (1|1.), Qc_,initPhases:{_,_,_,_}:{0,0,0,0}] := Module[{consts, assoc, t, r, \[Theta], \[Phi], En, L, Q, \[CapitalUpsilon]r,\[CapitalUpsilon]\[Theta],\[CapitalUpsilon]\[Phi],\[CapitalUpsilon]t, e=0, x=1,r1,r2,r3,r4,velocity,type},

	{\[CapitalUpsilon]r,\[CapitalUpsilon]\[Theta],\[CapitalUpsilon]\[Phi],\[CapitalUpsilon]t} = Values[KerrGeoMinoFrequencies[a,p,e,x,Qc]];
	{r1,r2,r3,r4} = KerrGeoRadialRoots[a, p, e, x, Qc];
	consts = KerrGeoConstantsOfMotionN[a,p,e,Qc];
	{En,L,Q} = Values[consts];

	t=Function[{Global`\[Lambda]}, Evaluate[  ((a^3 Sqrt[2 a+(-3+p) Sqrt[p]] p^2+a Sqrt[2 a+(-3+p) Sqrt[p]] (-2+p) p^3+a^2 Sqrt[(2 a+(-3+p) Sqrt[p]) p^7]-2 Sqrt[(2 a+(-3+p) Sqrt[p]) p^9]+Sqrt[(2 a+(-3+p) Sqrt[p]) p^11]) Global`\[Lambda])/((2 a+(-3+p) Sqrt[p]) p^(3/4) (a^2+(-2+p) p)) ], Listable];
	r=Function[{Global`\[Lambda]}, Evaluate[  p ], Listable];
	\[Theta]=Function[{Global`\[Lambda]}, Evaluate[  \[Pi]/2 ], Listable];
	\[Phi]=Function[{Global`\[Lambda]}, Evaluate[  (p^(5/4) Global`\[Lambda])/Sqrt[2 a+(-3+p) Sqrt[p]] ], Listable];
	
	velocity = Values[KerrGeoFourVelocity[a,p,e,x,Qc,{initPhases[[2]],initPhases[[3]]}]];

	type = KerrGeoOrbitType[a,p,e,x];

	assoc = Association[
		"Parametrization"->"Mino", 
		"Energy" -> En, 
		"AngularMomentum" -> L, 
		"CarterConstant" -> Q, 
		"ConstantsOfMotion" -> consts,
		"RadialRoots"-> {r1,r2,r3,r4},
		"RadialFrequency" -> \[CapitalUpsilon]r,
		"PolarFrequency" ->  \[CapitalUpsilon]\[Theta],
		"AzimuthalFrequency" -> \[CapitalUpsilon]\[Phi],
		"RadialRoots" -> {r1,r2,r3,r4},
		"Frequencies" -> <|"\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(r\)]\)" ->  \[CapitalUpsilon]r, "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Theta]\)]\)" ->  \[CapitalUpsilon]\[Theta], "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Phi]\)]\)" ->  \[CapitalUpsilon]\[Phi], "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(t\)]\)" ->  \[CapitalUpsilon]t |>,
		"Trajectory" -> {t,r,\[Theta],\[Phi]},
		"FourVelocity" -> velocity,
		"a" -> a,
		"p" -> p,
		"e" -> e,
		"Inclination" -> x,
		"Qc" -> Qc,
		"Type" -> type,
		"InitialPhases" -> initPhases
	];
	
	KerrGeoOrbitFunction[a, p, e, x, Qc, assoc]
]



(* ::Subsection:: *)
(*Generic (Mino)*)


KerrGeoOrbitPhases[a_,p_,e_,x_,Qc_,initPhases:{_,_,_,_}:{0,0,0,0}]:=Module[
{M=1,consts,En,L,Q,assoc,\[CapitalUpsilon]r,\[CapitalUpsilon]\[Theta],\[CapitalUpsilon]\[Phi],\[CapitalUpsilon]t,r1,r2,r3,r4,zp,zm,kr,k\[Theta],rp,rm,hr,hp,hm,rq,zq,\[Psi]r,tr,\[Phi]f,\[Psi]z,tz,\[Phi]z,t,r,\[Theta],\[Phi],\[Phi]t,\[Phi]r,Ct,C\[Phi],velocity,\[CapitalDelta]tr,\[CapitalDelta]t\[Theta],\[CapitalDelta]\[Phi]r,\[CapitalDelta]\[Phi]\[Theta],type},
	
consts = KerrGeoConstantsOfMotionN[a,p,e,Qc];
{En,L,Q} = Values[consts];
{\[CapitalUpsilon]r,\[CapitalUpsilon]\[Theta],\[CapitalUpsilon]\[Phi],\[CapitalUpsilon]t} = Values[KerrGeoMinoFrequencies[a,p,e,x,Qc]];
{r1,r2,r3,r4} = KerrGeoRadialRoots[a, p, e, x, Qc];
{zp,zm} = KerrGeoPolarRoots[a, p, e, x, Qc];	
kr = (r1-r2)/(r1-r3) (r3-r4)/(r2-r4);
k\[Theta] = a^2 (1-En^2)(zm/zp)^2;

rp=M+Sqrt[M^2-a^2];
rm=M-Sqrt[M^2-a^2];
hr=(r1-r2)/(r1-r3);
hp=((r1-r2)(r3-rp))/((r1-r3)(r2-rp));
hm=((r1-r2)(r3-rm))/((r1-r3)(r2-rm));


rq = Function[{qr},(r3(r1 - r2)JacobiSN[EllipticK[kr]/\[Pi] qr,kr]^2-r2(r1-r3))/((r1-r2)JacobiSN[EllipticK[kr]/\[Pi] qr,kr]^2-(r1-r3))];

zq = Function[{qz}, zm JacobiSN[EllipticK[k\[Theta]] 2/\[Pi] (qz+\[Pi]/2),k\[Theta]]];

\[Psi]r[qr_]:=\[Psi]r[qr]= JacobiAmplitude[EllipticK[kr]/\[Pi] qr,kr];

tr[qr_]:= -En/Sqrt[(1-En^2) (r1-r3) (r2-r4)] (
4(r2-r3) (EllipticPi[hr,kr] qr/\[Pi]-EllipticPi[hr,\[Psi]r[qr],kr])
-4 (r2-r3)/(rp-rm) (
-(1/((-rm+r2) (-rm+r3)))(-2 a^2+rm (4-(a L)/En)) (EllipticPi[hm,kr] qr/\[Pi]-EllipticPi[hm,\[Psi]r[qr],kr] )
+1/((-rp+r2) (-rp+r3)) (-2 a^2+rp (4-(a L)/En)) (EllipticPi[hp,kr] qr/\[Pi]-EllipticPi[hp,\[Psi]r[qr],kr])
)
+(r2-r3) (r1+r2+r3+r4) (EllipticPi[hr,kr] qr/\[Pi]-EllipticPi[hr,\[Psi]r[qr],kr] )
+(r1-r3) (r2-r4) (EllipticE[kr] qr/\[Pi]-EllipticE[\[Psi]r[qr],kr]+hr((Sin[\[Psi]r[qr]]Cos[\[Psi]r[qr]] Sqrt[1-kr Sin[\[Psi]r[qr]]^2])/(1-hr Sin[\[Psi]r[qr]]^2))) );

\[Phi]r[qr_]:= (2 a En (-1/((-rm+r2) (-rm+r3))(2 rm-(a L)/En) (r2-r3) (EllipticPi[hm,kr] qr/\[Pi]-EllipticPi[hm,\[Psi]r[qr],kr])+1/((-rp+r2) (-rp+r3))(2 rp-(a L)/En) (r2-r3) (EllipticPi[hp,kr] qr/\[Pi]-EllipticPi[hp,\[Psi]r[qr],kr] )))/((-rm+rp) Sqrt[(1-En^2) (r1-r3) (r2-r4)]);

\[Psi]z[qz_]:= \[Psi]z[qz] = JacobiAmplitude[EllipticK[k\[Theta]] 2/\[Pi] (qz+\[Pi]/2),k\[Theta]];
tz[qz_]:= 1/(1-En^2) En zp ( EllipticE[k\[Theta]]2((qz+\[Pi]/2)/\[Pi])-EllipticE[\[Psi]z[qz],k\[Theta]]);
\[Phi]z[qz_]:= -1/zp L ( EllipticPi[zm^2,k\[Theta]]2((qz+\[Pi]/2)/\[Pi])-EllipticPi[zm^2,\[Psi]z[qz],k\[Theta]]);


t=Function[{Global`qt,Global`qr,Global`q\[Theta]}, Evaluate[ Global`qt+ tr[Global`qr] + tz[Global`q\[Theta]]], Listable];
r=Function[{Global`qr}, Evaluate[ rq[Global`qr] ], Listable];
\[Theta]=Function[{Global`q\[Theta]}, Evaluate[ ArcCos[zq[Global`q\[Theta]]] ], Listable];
\[Phi]=Function[{Global`q\[Phi],Global`qr,Global`q\[Theta]}, Evaluate[ Global`q\[Phi] + \[Phi]r[Global`qr] + \[Phi]z[Global`q\[Theta]]], Listable];

\[CapitalDelta]tr=Function[{Global`qr}, Evaluate[ tr[Global`qr] ], Listable];
\[CapitalDelta]t\[Theta]=Function[{Global`q\[Theta]}, Evaluate[ tz[Global`q\[Theta]] ], Listable];
\[CapitalDelta]\[Phi]r=Function[{Global`qr}, Evaluate[ \[Phi]r[Global`qr] ], Listable];
\[CapitalDelta]\[Phi]\[Theta]=Function[{Global`q\[Theta]}, Evaluate[ \[Phi]z[Global`q\[Theta]] ], Listable];

type = KerrGeoOrbitType[a,p,e,x];

	assoc = Association[
	"a" -> a,
	"p" -> p,
	"e" -> e,
	"Inclination" -> x,
	"Parametrization"->"Phases", 
	"Energy" -> En, 
	"AngularMomentum" -> L, 
	"CarterConstant" -> Q, 
	"ConstantsOfMotion" -> consts,
	"RadialFrequency" -> \[CapitalUpsilon]r,
	"PolarFrequency" ->  \[CapitalUpsilon]\[Theta],
	"AzimuthalFrequency" -> \[CapitalUpsilon]\[Phi],
	"Frequencies" -> <|"\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(r\)]\)" ->  \[CapitalUpsilon]r, "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Theta]\)]\)" ->  \[CapitalUpsilon]\[Theta], "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Phi]\)]\)" ->  \[CapitalUpsilon]\[Phi] ,"\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(t\)]\)" ->  \[CapitalUpsilon]t |> ,
	"Trajectory" -> {t,r,\[Theta],\[Phi]},
	"TrajectoryDeltas" -> <|"\[CapitalDelta]tr"-> \[CapitalDelta]tr,"\[CapitalDelta]t\[Theta]"-> \[CapitalDelta]t\[Theta],"\[CapitalDelta]\[Phi]r"-> \[CapitalDelta]\[Phi]r,"\[CapitalDelta]\[Phi]\[Theta]"-> \[CapitalDelta]\[Phi]\[Theta]|>,
	"RadialRoots" -> {r1,r2,r3,r4},
	"a" -> a,
	"p" -> p,
	"e" -> e,
	"Inclination" -> x,
	"Qc" -> Qc,
	"Type" -> type,
	"InitialPhases" -> {0, 0, 0, 0}
	];


KerrGeoOrbitFunction[a,p,e,x,Qc,assoc]

]



(* ::Subsubsection:: *)
(*Scattering orbit (e > 1)*)


KerrGeoOrbitMino[a_,p_,e_/;Abs@e>1,x_,Qc_,initPhases:{_,_,_,_}:{0,0,0,0}]:=Module[
{M=1,consts,En,L,Q,assoc,\[CapitalUpsilon]r,\[CapitalUpsilon]\[Theta],\[CapitalUpsilon]\[Phi],\[CapitalUpsilon]t,r1,r2,r3,r4,zp,zm,kr,k\[Theta],rp,rm,hr,hp,hm,rq,zq,\[Psi]r,tr,\[Phi]f,\[Psi]z,tz,\[Phi]z,qt0,qr0,qz0,q\[Phi]0,t,r,\[Theta],\[Phi],\[Phi]t,\[Phi]r,Ct,C\[Phi],qrS,\[Lambda]S,\[Phi]S,\[Theta]in,\[Theta]out,type},
	consts = KerrGeoConstantsOfMotionN[a,p,e,Qc];
	{En,L,Q} = {"\[ScriptCapitalE]","\[ScriptCapitalL]","\[ScriptCapitalQ]"}/.consts;
	{\[CapitalUpsilon]r,\[CapitalUpsilon]\[Theta],\[CapitalUpsilon]\[Phi],\[CapitalUpsilon]t} = Values[KerrGeoMinoFrequencies[a,p,e,x]];
	{r1,r2,r3,r4} = KerrGeoRadialRoots[a, p, e, x, En, Q];
	{zp,zm} = KerrGeoPolarRoots[a, p, e, x];
	
	kr = (r1-r2)/(r1-r3) (r3-r4)/(r2-r4);
	k\[Theta] = a^2 (1-En^2)(zm/zp)^2;

rp=M+Sqrt[M^2-a^2];
rm=M-Sqrt[M^2-a^2];
hr=(r2-r1)/(r3-r1);
hp=((r2-r1)(r3-rp))/((r3-r1)(r2-rp));
hm=((r2-r1)(r3-rm))/((r3-r1)(r2-rm));

rq = Function[{qr},(r3(r1 - r2)JacobiSN[EllipticK[kr]/\[Pi] qr,kr]^2-r2(r1-r3))/((r1-r2)JacobiSN[EllipticK[kr]/\[Pi] qr,kr]^2-(r1-r3))];

zq = Function[{qz}, zm JacobiSN[EllipticK[k\[Theta]] 2/\[Pi] (qz+\[Pi]/2),k\[Theta]]];

\[Psi]r[qr_]:=\[Psi]r[qr]= JacobiAmplitude[EllipticK[kr]/\[Pi] qr,kr];

tr[qr_]:= -En/Sqrt[(En^2-1) (r3-r1) (r2-r4)] (
4(r2-r3) (EllipticPi[hr,kr] qr/\[Pi]-EllipticPi[hr,\[Psi]r[qr],kr])
-4 (r2-r3)/(rp-rm) (
-(1/((-rm+r2) (-rm+r3)))(-2 a^2+rm (4-(a L)/En)) (EllipticPi[hm,kr] qr/\[Pi]-EllipticPi[hm,\[Psi]r[qr],kr] )
+1/((-rp+r2) (-rp+r3)) (-2 a^2+rp (4-(a L)/En)) (EllipticPi[hp,kr] qr/\[Pi]-EllipticPi[hp,\[Psi]r[qr],kr])
)
+(r2-r3) (r1+r2+r3+r4) (EllipticPi[hr,kr] qr/\[Pi]-EllipticPi[hr,\[Psi]r[qr],kr] )
+(r1-r3) (r2-r4) (EllipticE[kr] qr/\[Pi]-EllipticE[\[Psi]r[qr],kr]+hr((Sin[\[Psi]r[qr]]Cos[\[Psi]r[qr]] Sqrt[1-kr Sin[\[Psi]r[qr]]^2])/(1-hr Sin[\[Psi]r[qr]]^2))) );

\[Phi]r[qr_]:= (2 a En (-1/((-rm+r2) (-rm+r3))(2 rm-(a L)/En) (r2-r3) (EllipticPi[hm,kr] qr/\[Pi]-EllipticPi[hm,\[Psi]r[qr],kr])+1/((-rp+r2) (-rp+r3))(2 rp-(a L)/En) (r2-r3) (EllipticPi[hp,kr] qr/\[Pi]-EllipticPi[hp,\[Psi]r[qr],kr] )))/((-rm+rp) Sqrt[(1-En^2) (r1-r3) (r2-r4)]);

\[Psi]z[qz_]:= \[Psi]z[qz] = JacobiAmplitude[EllipticK[k\[Theta]] 2/\[Pi] (qz+\[Pi]/2),k\[Theta]];
tz[qz_]:= 1/(1-En^2) En zp ( EllipticE[k\[Theta]]2((qz+\[Pi]/2)/\[Pi])-EllipticE[\[Psi]z[qz],k\[Theta]]);
\[Phi]z[qz_]:= -1/zp L ( EllipticPi[zm^2,k\[Theta]]2((qz+\[Pi]/2)/\[Pi])-EllipticPi[zm^2,\[Psi]z[qz],k\[Theta]]);

qrS = (\[Pi] InverseJacobiSN[Sqrt[(r3-r1)/(r2-r1)],kr])/EllipticK[kr];
\[Lambda]S= qrS/\[CapitalUpsilon]r;

{qt0, qr0, qz0, q\[Phi]0} = {initPhases[[1]], initPhases[[2]], initPhases[[3]], initPhases[[4]]};
If[qr0 != 0, Print["Scattering orbits are assumed to have \!\(\*SubscriptBox[\(q\), \(r, 0\)]\)=0"];qr0=0];

(*Calculate normalization constants so that t=0 and \[Phi]=0 at \[Lambda]=0 when qt0=0 and q\[Phi]0=0 *)
Ct=tr[qr0]+tz[qz0]/.i_/;i==0:>0;
C\[Phi]=\[Phi]r[qr0]+\[Phi]z[qz0]/.i_/;i==0:>0;

\[Phi]S = 2 \[CapitalUpsilon]\[Phi] \[Lambda]S+ \[Phi]z[\[CapitalUpsilon]\[Theta] \[Lambda]S + qz0]- \[Phi]z[-\[CapitalUpsilon]\[Theta] \[Lambda]S + qz0];
\[Theta]in=ArcCos[zq[-\[CapitalUpsilon]\[Theta] \[Lambda]S + qz0]];
\[Theta]out=ArcCos[zq[\[CapitalUpsilon]\[Theta] \[Lambda]S + qz0]];

t=Function[{Global`\[Lambda]}, Evaluate[ qt0 + \[CapitalUpsilon]t Global`\[Lambda] + tr[\[CapitalUpsilon]r Global`\[Lambda] + qr0] + tz[\[CapitalUpsilon]\[Theta] Global`\[Lambda] + qz0]-Ct ], Listable];
r=Function[{Global`\[Lambda]}, Evaluate[ rq[\[CapitalUpsilon]r Global`\[Lambda]+ qr0] ], Listable];
\[Theta]=Function[{Global`\[Lambda]}, Evaluate[ ArcCos[zq[\[CapitalUpsilon]\[Theta] Global`\[Lambda] + qz0]] ], Listable];
\[Phi]=Function[{Global`\[Lambda]}, Evaluate[ q\[Phi]0 + \[CapitalUpsilon]\[Phi] Global`\[Lambda] + \[Phi]r[\[CapitalUpsilon]r Global`\[Lambda]+ qr0] + \[Phi]z[\[CapitalUpsilon]\[Theta] Global`\[Lambda] + qz0]-C\[Phi] ], Listable];

type = KerrGeoOrbitType[a,p,e,x];

assoc = Association[
	"Parametrization"->"Mino", 
	"Energy" -> En, 
	"AngularMomentum" -> L, 
	"CarterConstant" -> Q, 
	"ConstantsOfMotion" -> Join[consts,<|"\[Psi]"-> \[Phi]S-\[Pi],
	"ScatteringInclinations"-> <|"\!\(\*SubscriptBox[\(\[Theta]\), \(in\)]\)"-> \[Theta]in,"\!\(\*SubscriptBox[\(\[Theta]\), \(out\)]\)"-> \[Theta]out|>|>],
	"RadialFrequency" -> \[CapitalUpsilon]r,
	"PolarFrequency" ->  \[CapitalUpsilon]\[Theta],
	"AzimuthalFrequency" -> \[CapitalUpsilon]\[Phi],
	"Frequencies" -> <|"\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(r\)]\)"-> \[CapitalUpsilon]r,"\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Theta]\)]\)"->\[CapitalUpsilon]\[Theta],"\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Phi]\)]\)"->\[CapitalUpsilon]\[Phi]|>,
	"Trajectory" -> {t,r,\[Theta],\[Phi]},
	"RadialRoots" -> {r1,r2,r3,r4},
	"ParameterRange"-> {-\[Lambda]S,\[Lambda]S},
	"a" -> a,
	"p" -> p,
	"e" -> e,
	"Type" -> type,
	"Inclination" -> x
	];

KerrGeoOrbitFunction[a,p,e,x,Qc,assoc]
	
]

KerrGeoOrbitMino[a_,p_,e_,x_,Qc_,initPhases:{_,_,_,_}:{0,0,0,0}]:=Module[{M=1,assoc,qt0,qr0,qz0,q\[Phi]0,tr,tz,t,r,\[Theta],\[Phi],\[Phi]z,\[Phi]r,Ct,C\[Phi],velocity,\[CapitalUpsilon]r,\[CapitalUpsilon]\[Theta],\[CapitalUpsilon]\[Phi],\[CapitalUpsilon]t},
	assoc= Last@KerrGeoOrbitPhases[a,p,e,x,Qc];
	
	{qt0, qr0, qz0, q\[Phi]0} = {initPhases[[1]], initPhases[[2]], initPhases[[3]], initPhases[[4]]};
	
	{\[CapitalUpsilon]r,\[CapitalUpsilon]\[Theta],\[CapitalUpsilon]\[Phi],\[CapitalUpsilon]t}=Values@assoc["Frequencies"];
	{t,r,\[Theta],\[Phi]}=assoc["Trajectory"];
	
	tr=assoc["TrajectoryDeltas"]["\[CapitalDelta]tr"];
	tz=assoc["TrajectoryDeltas"]["\[CapitalDelta]t\[Theta]"];
	\[Phi]r=assoc["TrajectoryDeltas"]["\[CapitalDelta]\[Phi]r"];
	\[Phi]z=assoc["TrajectoryDeltas"]["\[CapitalDelta]\[Phi]\[Theta]"];

	(*Calculate normalization constants so that t=0 and \[Phi]=0 at \[Lambda]=0 when qt0=0 and q\[Phi]0=0 *)
	Ct=tr[qr0]+tz[qz0]/.i_/;i==0:>0;
	C\[Phi]=\[Phi]r[qr0]+\[Phi]z[qz0]/.i_/;i==0:>0;

	t=Function[{Global`\[Lambda]}, Evaluate[ t[qt0 + \[CapitalUpsilon]t Global`\[Lambda], \[CapitalUpsilon]r Global`\[Lambda] + qr0, \[CapitalUpsilon]\[Theta] Global`\[Lambda] + qz0]-Ct ], Listable];
	r=Function[{Global`\[Lambda]}, Evaluate[ r[\[CapitalUpsilon]r Global`\[Lambda]+ qr0] ], Listable];
	\[Theta]=Function[{Global`\[Lambda]}, Evaluate[ \[Theta][\[CapitalUpsilon]\[Theta] Global`\[Lambda] + qz0] ], Listable];
	\[Phi]=Function[{Global`\[Lambda]}, Evaluate[ \[Phi][q\[Phi]0 + \[CapitalUpsilon]\[Phi] Global`\[Lambda] ,\[CapitalUpsilon]r Global`\[Lambda]+ qr0,\[CapitalUpsilon]\[Theta] Global`\[Lambda] + qz0]-C\[Phi] ], Listable];

	velocity = Values[KerrGeoFourVelocity[a,p,e,x,Qc,{qr0,qz0}]];

	assoc["Parametrization"] = "Mino";
	assoc["Trajectory"] = {t,r,\[Theta],\[Phi]};
	assoc["FourVelocity"] = velocity;
	assoc["InitialPhases"] = {qt0, qr0, qz0, q\[Phi]0};
	
	KerrGeoOrbitFunction[a,p,e,x,Qc,assoc]

]



(* ::Subsection:: *)
(*Generic (Fast Spec - Mino)*)


(* ::Subsubsection:: *)
(*Subroutines for calculating \[Lambda](\[Psi]) and \[Lambda](\[Chi])*)


Clear[MinoRFastSpec];
MinoRFastSpec[a_,p_,e_,x_,Qc_]:=
Module[{M=1,En,L,Q,\[CapitalUpsilon]r,\[CapitalUpsilon]\[Theta],\[CapitalUpsilon]\[Phi],\[CapitalUpsilon]t,r1,r2,r3,r4,\[Psi]r,r0,p3,p4,Pr,PrSample,NrInit=2^4,
		\[ScriptCapitalP]rSample,\[ScriptCapitalP]rn,\[ScriptCapitalP]rList,\[CapitalDelta]\[Lambda]r,pg,iter=1,compare,res,rate},
	{En,L,Q} = Values[KerrGeoConstantsOfMotionN[a,p,e,Qc]];
	{r1,r2,r3,r4} = KerrGeoRadialRoots[a, p, e, x,  Qc];
	p3=(1-e)r3/M;
	p4=(1+e)r4/M;
	pg=Precision[{a,p,e,x}];
	
	If[pg==$MachinePrecision,
		\[Psi]r[Nr_]:=N[Table[i Pi/(Nr-1),{i,0,Nr-1}]],
		\[Psi]r[Nr_]:=N[Table[i Pi/(Nr-1),{i,0,Nr-1}],1.5pg]
	];
	
	Pr[psi_]:=Pr[psi]=(1-e^2)((p-p4)+e(p-p4 Cos[psi]))^(-1/2)/(M (1-En^2)^(1/2)((p-p3)-e(p+p3 Cos[psi]))^(1/2));
	PrSample[Nr_]:=Pr[\[Psi]r[Nr]];
	
	{rate,\[CapitalDelta]\[Lambda]r}=DarwinFastSpecIntegrateAndConvergenceCheck[PrSample];
	\[CapitalDelta]\[Lambda]r
];

Clear[MinoThetaFastSpec];
MinoThetaFastSpec[a_,p_,e_,x_,Qc_]:=
Module[{M=1,En,L,Q,zp,zm,\[Chi]\[Theta],\[Beta],P\[Theta],P\[Theta]Sample,NthInit=2^4,\[ScriptCapitalP]\[Theta]List,\[ScriptCapitalP]\[Theta]Sample,
	\[ScriptCapitalP]\[Theta]k,\[CapitalDelta]\[Lambda]\[Theta],pg,iter=1,compare,res,\[Alpha],rate},
	{En,L,Q} = Values[KerrGeoConstantsOfMotionN[a,p,e,Qc]];
	\[Beta]=a^2(1-En^2);
	\[Alpha]=L^2+Q+\[Beta];
	zp=Sqrt[(\[Alpha]+Sqrt[\[Alpha]^2-4 Q \[Beta]])/(2\[Beta])];
	zm=Sqrt[(\[Alpha]-Sqrt[\[Alpha]^2-4 Q \[Beta]])/(2\[Beta])];
	pg=Precision[{a,p,e,x}];
	
	If[pg==$MachinePrecision,
		\[Chi]\[Theta][Nth_]:=N[Table[i Pi/(Nth-1),{i,0,Nth-1}]],
		\[Chi]\[Theta][Nth_]:=N[Table[i Pi/(Nth-1),{i,0,Nth-1}],1.5pg]
	];
	P\[Theta][chi_]:=P\[Theta][chi]=(\[Beta](zp^2-zm^2 Cos[chi]^2))^(-1/2);
	P\[Theta]Sample[Nth_]:=P\[Theta][\[Chi]\[Theta][Nth]];
	
	{rate,\[CapitalDelta]\[Lambda]\[Theta]}=DarwinFastSpecIntegrateAndConvergenceCheck[P\[Theta]Sample];
	\[CapitalDelta]\[Lambda]\[Theta]
];



(* ::Subsubsection:: *)
(*Subroutine for calculating \[Psi](\[Lambda]) and \[Chi](\[Lambda])*)


PhaseOfMinoFastSpec[\[CapitalUpsilon]_,sampledMino_]:=
Module[{sampledFunc,NInit,phase},
	NInit=Length[sampledMino];
	sampledFunc[NN_]:=ConstantArray[1,NN];
	phase=DarwinFastSpecMinoIntegrateAndConvergenceCheck[sampledFunc,{\[CapitalUpsilon],sampledMino}];
	phase
];


(* ::Subsubsection:: *)
(*Subroutines for calculating Subscript[\[CapitalDelta]\[Phi], r](Subscript[q, r]), Subscript[\[CapitalDelta]\[Phi], \[Theta]](Subscript[q, \[Theta]]), Subscript[\[CapitalDelta]t, r](Subscript[q, r]), Subscript[\[CapitalDelta]t, \[Theta]](Subscript[q, \[Theta]])*)


PhiOfMinoFastSpecR[a_,p_,e_,x_,Qc_,{\[CapitalUpsilon]r_,minoSampleR_}]:=
Module[{M=1,En,L,Q,sampledFuncR,sampledMinoR,PVr,\[CapitalDelta]\[Phi]r},
	{En,L,Q} = Values[KerrGeoConstantsOfMotionN[a,p,e,Qc]];
	PVr[rp_]:=-((a^2*L)/(a^2 - 2*M*rp + rp^2)) + a*En*(-1 + (a^2 + rp^2)/(a^2 - 2*M*rp + rp^2));

	sampledFuncR=LambdaToPsiRTransform[a,p,e,x,Qc,PVr];
	\[CapitalDelta]\[Phi]r=DarwinFastSpecMinoIntegrateAndConvergenceCheck[sampledFuncR,{\[CapitalUpsilon]r,minoSampleR}];
	\[CapitalDelta]\[Phi]r
];

PhiOfMinoFastSpecR[a_,p_,e_,x_,Qc_]:=Module[{\[CapitalUpsilon]r,\[CapitalDelta]\[Lambda]r,\[Lambda]r,\[Lambda]rSample,pg,\[Psi]r},
	\[CapitalUpsilon]r = Re[KerrGeoMinoFrequencies[a,p,e,x,Qc]][[1]];
	pg=Precision[{a,p,e,x}];

	If[pg==$MachinePrecision,
		\[Psi]r[Nr_]:=N[Table[i 2 Pi/Nr,{i,0,Nr-1}]],
		\[Psi]r[Nr_]:=N[Table[i 2 Pi/Nr,{i,0,Nr-1}],1.5pg]
	];
	\[CapitalDelta]\[Lambda]r=MinoRFastSpec[a,p,e,x,Qc];
	\[Lambda]r[psi_]:=\[Lambda]r[psi]=\[CapitalDelta]\[Lambda]r[psi];
	\[Lambda]rSample[Nr_]:=\[Lambda]r[\[Psi]r[Nr]];
	PhiOfMinoFastSpecR[a,p,e,x,Qc,{\[CapitalUpsilon]r,\[Lambda]rSample}]
];


PhiOfMinoFastSpecTheta[a_,p_,e_,x_,Qc_,{\[CapitalUpsilon]\[Theta]_,minoSampleTh_}]:=
Module[{M=1,En,L,Q,sampledFuncTheta,sampledMinoTheta,PV\[Theta],\[CapitalDelta]\[Phi]\[Theta]},
	{En,L,Q} = Values[KerrGeoConstantsOfMotionN[a,p,e,Qc]];
	PV\[Theta][\[Theta]p_]:=L*Csc[\[Theta]p]^2;
	
	sampledFuncTheta=LambdaToChiThetaTransform[a,p,e,x,Qc,PV\[Theta]];
	\[CapitalDelta]\[Phi]\[Theta]=DarwinFastSpecMinoIntegrateAndConvergenceCheck[sampledFuncTheta,{\[CapitalUpsilon]\[Theta],minoSampleTh}];
	\[CapitalDelta]\[Phi]\[Theta]
];

PhiOfMinoFastSpecTheta[a_,p_,e_,x_,Qc_]:=Module[{\[CapitalUpsilon]\[Theta],\[CapitalDelta]\[Lambda]\[Theta],\[Lambda]\[Theta],\[Lambda]\[Theta]Sample,pg,\[Chi]\[Theta]},
	\[CapitalUpsilon]\[Theta] = Re[KerrGeoMinoFrequencies[a,p,e,x,Qc]][[2]];
	pg=Precision[{a,p,e,x}];

	If[pg==$MachinePrecision,
		\[Chi]\[Theta][Nth_]:=N[Table[i 2 Pi/Nth,{i,0,Nth-1}]],
		\[Chi]\[Theta][Nth_]:=N[Table[i 2 Pi/Nth,{i,0,Nth-1}],1.5pg]
	];
	\[CapitalDelta]\[Lambda]\[Theta]=MinoRFastSpec[a,p,e,x,Qc];
	\[Lambda]\[Theta][psi_]:=\[Lambda]\[Theta][psi]=\[CapitalDelta]\[Lambda]\[Theta][psi];
	\[Lambda]\[Theta]Sample[Nr_]:=\[Lambda]\[Theta][\[Chi]\[Theta][Nr]];
	PhiOfMinoFastSpecTheta[a,p,e,x,Qc,{\[CapitalUpsilon]\[Theta],\[Lambda]\[Theta]Sample}]
];


TimeOfMinoFastSpecR[a_,p_,e_,x_,Qc_,{\[CapitalUpsilon]r_,minoSampleR_}]:=
Module[{M=1,En,L,Q,sampledFuncR,sampledMinoR,TVr,\[CapitalDelta]tr},
	{En,L,Q} = Values[KerrGeoConstantsOfMotionN[a,p,e,Qc]];
	TVr[rp_]:=(En*(a^2 + rp^2)^2)/(a^2 - 2*M*rp + rp^2) + a*L*(1 - (a^2 + rp^2)/(a^2 - 2*M*rp + rp^2));

	sampledFuncR=LambdaToPsiRTransform[a,p,e,x,Qc,TVr];
	\[CapitalDelta]tr=DarwinFastSpecMinoIntegrateAndConvergenceCheck[sampledFuncR,{\[CapitalUpsilon]r,minoSampleR}];
	\[CapitalDelta]tr
];

TimeOfMinoFastSpecR[a_,p_,e_,x_,Qc_]:=Module[{\[CapitalUpsilon]r,\[CapitalDelta]\[Lambda]r,\[Lambda]r,\[Lambda]rSample,pg,\[Psi]r},
	\[CapitalUpsilon]r = Re[KerrGeoMinoFrequencies[a,p,e,x,Qc]][[1]];
	pg=Precision[{a,p,e,x}];

	If[pg==$MachinePrecision,
		\[Psi]r[Nr_]:=N[Table[i 2 Pi/Nr,{i,0,Nr-1}]],
		\[Psi]r[Nr_]:=N[Table[i 2 Pi/Nr,{i,0,Nr-1}],1.5pg]
	];
	\[CapitalDelta]\[Lambda]r=MinoRFastSpec[a,p,e,x,Qc];
	\[Lambda]r[psi_]:=\[Lambda]r[psi]=\[CapitalDelta]\[Lambda]r[psi];
	\[Lambda]rSample[Nr_]:=\[Lambda]r[\[Psi]r[Nr]];
	TimeOfMinoFastSpecR[a,p,e,x,Qc,{\[CapitalUpsilon]r,\[Lambda]rSample}]
];


TimeOfMinoFastSpecTheta[a_,p_,e_,x_,Qc_,{\[CapitalUpsilon]\[Theta]_,minoSampleTh_}]:=
Module[{M=1,En,L,Q,sampledFuncTheta,sampledMinoTheta,TV\[Theta],\[CapitalDelta]t\[Theta]},
	{En,L,Q} = Values[KerrGeoConstantsOfMotionN[a,p,e,Qc]];
	TV\[Theta][\[Theta]p_]:=-(a^2*En*Sin[\[Theta]p]^2);

	sampledFuncTheta=LambdaToChiThetaTransform[a,p,e,x,Qc,TV\[Theta]];
	\[CapitalDelta]t\[Theta]=DarwinFastSpecMinoIntegrateAndConvergenceCheck[sampledFuncTheta,{\[CapitalUpsilon]\[Theta],minoSampleTh}];
	\[CapitalDelta]t\[Theta]
];

TimeOfMinoFastSpecTheta[a_,p_,e_,x_,Qc_]:=Module[{\[CapitalUpsilon]\[Theta],\[CapitalDelta]\[Lambda]\[Theta],\[Lambda]\[Theta],\[Lambda]\[Theta]Sample,pg,\[Chi]\[Theta]},
	\[CapitalUpsilon]\[Theta] = Re[KerrGeoMinoFrequencies[a,p,e,x,Qc]][[2]];
	pg=Precision[{a,p,e,x}];

	If[pg==$MachinePrecision,
		\[Chi]\[Theta][Nr_]:=N[Table[i 2 Pi/Nr,{i,0,Nr-1}]],
		\[Chi]\[Theta][Nr_]:=N[Table[i 2 Pi/Nr,{i,0,Nr-1}],1.5pg]
	];
	\[CapitalDelta]\[Lambda]\[Theta]=MinoRFastSpec[a,p,e,x,Qc];
	\[Lambda]\[Theta][psi_]:=\[Lambda]\[Theta][psi]=\[CapitalDelta]\[Lambda]\[Theta][psi];
	\[Lambda]\[Theta]Sample[Nr_]:=\[Lambda]\[Theta][\[Chi]\[Theta][Nr]];
	TimeOfMinoFastSpecTheta[a,p,e,x,Qc,{\[CapitalUpsilon]\[Theta],\[Lambda]\[Theta]Sample}]
];


(* ::Subsubsection:: *)
(*Generic subroutines that transform functions from *)
(*\[Lambda] dependence to \[Psi] or \[Chi] dependence*)


LambdaToPsiRTransform[a_,p_,e_,x_,Qc_,rFunc_]:=
Module[{M=1,En,L,Q,r1,r2,r3,r4,p3,p4,\[Psi]r,r0,r0Sample,Pr,PrSample,rFuncSample,pg},
	{En,L,Q} = Values[KerrGeoConstantsOfMotionN[a,p,e,Qc]];
	{r1,r2,r3,r4} =KerrGeoRadialRoots[a, p, e, x, Qc];
	p3=(1-e)r3/M;
	p4=(1+e)r4/M;
	pg=Precision[{a,p,e,x}];

	If[pg==$MachinePrecision,
		\[Psi]r[Nr_]:=N[Table[i 2 Pi/Nr,{i,0,Nr-1}]],
		\[Psi]r[Nr_]:=N[Table[i 2 Pi/Nr,{i,0,Nr-1}],1.5pg]
	];
	r0[psi_]:=p M/(1+e Cos[psi]);
	r0Sample[Nr_]:=r0[\[Psi]r[Nr]];
	
	Pr[psi_]:=(1-e^2)/Sqrt[(p-p4)+e(p-p4 Cos[psi])]/(M (1-En^2)^(1/2)Sqrt[(p-p3)-e(p+p3 Cos[psi])]);
	PrSample[Nr_]:=Pr[\[Psi]r[Nr]];
	
	rFuncSample[Nr_]:=rFunc[r0Sample[Nr]]PrSample[Nr];
	rFuncSample
];


LambdaToChiThetaTransform[a_,p_,e_,x_,Qc_,thFunc_]:=
Module[{M=1,En,L,Q,zp,zm,\[Beta],\[Chi]\[Theta],\[Theta]0,\[Theta]0Sample,P\[Theta],P\[Theta]Sample,thFuncSample,pg,\[Alpha]},
	{En,L,Q} = Values[KerrGeoConstantsOfMotionN[a,p,e,Qc]];
	\[Beta]=a^2(1-En^2);
	\[Alpha]=L^2+Q+\[Beta];
	zp=Sqrt[(\[Alpha]+Sqrt[\[Alpha]^2-4 Q \[Beta]])/(2\[Beta])];
	zm=Sqrt[(\[Alpha]-Sqrt[\[Alpha]^2-4 Q \[Beta]])/(2\[Beta])];
	pg=Precision[{a,p,e,x}];
	
	If[pg==$MachinePrecision,
		\[Chi]\[Theta][Nth_]:=N[Table[i 2 Pi/Nth,{i,0,Nth-1}]],
		\[Chi]\[Theta][Nth_]:=N[Table[i 2 Pi/Nth,{i,0,Nth-1}],1.5pg]
	];
	\[Theta]0[chi_]:=ArcCos[zm Cos[chi]];
	\[Theta]0Sample[Nth_]:=\[Theta]0[\[Chi]\[Theta][Nth]];
	
	P\[Theta][chi_]:=(\[Beta](zp^2-zm^2 Cos[chi]^2))^(-1/2);
	P\[Theta]Sample[Nth_]:=P\[Theta][\[Chi]\[Theta][Nth]];
	
	thFuncSample[Nth_]:=thFunc[\[Theta]0Sample[Nth]]P\[Theta]Sample[Nth];
	thFuncSample
];


(* ::Subsubsection:: *)
(*Subroutines that checks for the number of samples necessary for spectral integration of an even function*)


Clear[DarwinFastSpecMinoIntegrateAndConvergenceCheck];
DarwinFastSpecMinoIntegrateAndConvergenceCheck[func_,{freq_,mino_}]:=
Module[{test,compare,res,NInit,iter=1,fn,sampledFunc,phaseList,pg,eps,nTest},
	(*
	DarwinFastSpecMinoIntegrateAndConvergenceCheck takes an even function 'func' 
	and determines the number of samples necessary to integrate 'func' with
	respect to Mino time \[Lambda] using spectral sampling in the Darwin-like parameters 
	\[Psi] and \[Chi]:
				-- func: a function that includes function values 
				that result from sampling the function at evenly spaced values 
				of the Darwin-like parameters \[Psi] or \[Chi]
				-- freq: Mino time frequency with respect to r or \[Theta] (\[CapitalUpsilon]r or \[CapitalUpsilon]\[Theta])
				-- mino: a list of Mino time values that results from 
				sampling the function at evenly spaced values of the Darwin-like 
				parameters \[Psi] or \[Chi] 
	*)
	
	(* Memoize function that we are integrating with respect to the Darwin parameter *)
	sampledFunc[NN_]:=sampledFunc[NN]=func[NN];
	(* Determine precision of arguments. 
	Use precision to check for convergence of spectral methods *)
	pg=Precision[freq];

	(* Treat machine precision calculations differently from arbitrary precision *)
	If[pg==MachinePrecision,
		(* eps sets the precision goal/numerical tolerance for our solutions *)
		eps=15;
		(* Set some initial value of sample points *)
		NInit=2^3;
		(* Sampled points need to also be weighted by the Mino time *)
		phaseList[NN_]:=phaseList[NN]=freq*mino[NN]+N[Table[2Pi i/NN,{i,0,NN-1}]];
		(* Create functions for discrete cosine series coefficient fn *)
		fn[NN_,nn_]:=Total[sampledFunc[NN]Cos[nn phaseList[NN]]]/NN;
		(* Test convergence by comparing coefficients to the n=0 coefficient*)
		nTest=0;
		test[NN_]:=fn[NN,nTest];
		(* If the n=0 coefficient vanishes or is unity, compare against n=1 coefficient *)
		If[test[NInit]==0||test[NInit]==1,nTest=1];
		(* Find the relative accuracy of the DFT coefficients by comparing the last 
		DFT coefficient to the test coefficient set above *)
		res[NN_]:=Abs@RealExponent[(fn[NN,NN/2]/.{y_/;y==0:>0})/fn[NN,0]];
		(* Find number of sample points necessary to match precision goal 'eps' *)
		While[res[NInit]<eps&&iter<8,NInit=2*NInit; iter++]
		,
		(* Set some initial value of sample points *)
		NInit=2^6;
		(* Same process as above but with higher precision tolerances *)
		phaseList[NN_]:=phaseList[NN]=freq*mino[NN]+N[Table[2Pi i/NN,{i,0,NN-1}],1.5pg];
		fn[NN_,nn_]:=Total[sampledFunc[NN]Cos[nn phaseList[NN]]]/NN;
		nTest=0;
		test[NN_]:=fn[NN,nTest];
		If[test[NInit]==0||test[NInit]==1,nTest=1];
		res[NN_]:=Abs@RealExponent[(fn[NN,NN/2]/.{y_/;y==0:>0})/fn[NN,0]];
		(* Also test for convergence by increasing the sample size until the test coefficient is unchanged *)
		compare=test[NInit/2];
		While[((compare =!= (compare = test[NInit]))||res[NInit/2]<pg+1)&&iter<10,NInit=2*NInit; iter++];
		(* Compare residuals by comparing to a different Fourier coefficient to ensure proper convergence *)
		(* This part might be overkill *)
		nTest++;
		compare=test[NInit/2];
		iter=1;
		While[((compare =!= (compare = test[NInit]))||res[NInit/2]<pg+1)&&iter<10,NInit=2*NInit; iter++];
		(* If the Fourier coefficients were unaffected after doubling the sampling size, 
		then we can sample using the previous number of sample points *)
		If[res[NInit]==0&&res[NInit/2]!=0,NInit,NInit=NInit/2];
	];
	(* After determining the necessary number of sample points, we sample the function
	we want to integrate and the Mino time, and pass both lists of sampled points to our
	spectral integrator *)
	DarwinFastSpecMinoIntegrateEven[sampledFunc[NInit],{freq,mino[NInit]}]
];


(* ::Subsubsection:: *)
(*Subroutine that performs spectral integration on even functions*)


DarwinFastSpecMinoIntegrateEven[sampledFunctionTemp_,{freq_,minoTimeTemp_}]:=
Module[{sampledF,fn,fList,f,sampleN,\[Lambda],integratedF,phaseList,pg,nn,samplePhase,nList,
		sampleMax,eps,sampleHalf},
	(*
	DarwinFastSpecMinoIntegrateEven takes an even function 'sampledFunctionTemp' 
	and integrates 'sampledFunctionTemp' with respect to Mino time \[Lambda] using spectral 
	sampling in the Darwin-like parameters \[Psi] and \[Chi]:
				-- sampledFunctionTemp: a list that includes function values 
				that result from sampling the function at evenly spaced values 
				of the Darwin-like parameters \[Psi] or \[Chi]
				-- freq: Mino time frequency with respect to r or \[Theta] (\[CapitalUpsilon]r or \[CapitalUpsilon]\[Theta])
				-- minoTimeTemp: a list of Mino time values that results from 
				sampling the function at evenly spaced values of the Darwin-like 
				parameters \[Psi] or \[Chi] 
	*)
	
	(* Represent values equal to zero with infinite precision *)
	sampledF=sampledFunctionTemp/.x_?NumericQ/;x==0:>0;
	\[Lambda]=minoTimeTemp/.x_?NumericQ/;x==0:>0;
	
	(* Determine the number of sampled points and precision of arguments *)
	sampleN=Length[sampledF];
	pg=Precision[freq];
	
	(* Use precision and number of sampled points to generate list of
	evenly spaced values of \[Psi] or \[Chi] *)
	If[pg==$MachinePrecision,
		phaseList=N[Table[2Pi i/sampleN,{i,0,sampleN-1}]],
		phaseList=N[Table[2Pi i/sampleN,{i,0,sampleN-1}],1.5pg]
	];
	
	(* Create functions for discrete cosine series coefficient fn *)
	samplePhase=(freq \[Lambda]+phaseList);
	fn[n_]:=fn[n]=(sampledF . Cos[nn*samplePhase])/.nn->n;
	
	(* Calculate series coefficients until they equal 0 (with respect 
	to the precision being used) *)
	If[pg==MachinePrecision,
		fList=Block[{halfSample,nIter},
			nIter=2^2+2;
			eps=15-RealExponent[Sum[Abs@fn[n],{n,0,nIter-2}]];
			While[(-RealExponent[fn[nIter]]<=eps||-RealExponent[fn[nIter-1]]<=eps)&&nIter<sampleN/2,nIter+=2];
			sampleMax=Min[nIter,sampleN/2];
			1/sampleN fn[Table[n,{n,0,sampleMax}]]/.x_?NumericQ/;x==0:>0
		],
		fList=Block[{halfSample,nIter},
			nIter=2^5+2;
			While[(fn[nIter]!=0||fn[nIter-1]!=0)&&nIter<sampleN/2,nIter+=2];
			sampleMax=Min[nIter,sampleN/2];
			1/sampleN fn[Table[n,{n,0,sampleMax}]]/.x_?NumericQ/;x==0:>0
		]
	];
	f[n_]:=fList[[n+1]];
	
	(* Construct integrated series solution *)
	integratedF = Function[{Global`phase},Evaluate[2*Sum[f[n]/n Sin[n Global`phase],{n,1,sampleMax}]],Listable];
	(* Allow function to evaluate lists by threading over them *)

	integratedF
];


(* ::Subsubsection:: *)
(*Main file that calculates geodesics using spectral integration*)


Clear[KerrGeoOrbitFastSpec];
Options[KerrGeoOrbitFastSpec]={"InitialPosition"->{0,0,0,0}};
KerrGeoOrbitFastSpec[a_,p_,e_,x_,Qc_,initPhases:{_,_,_,_}:{0,0,0,0},opts:OptionsPattern[]]:=
Module[{M=1,consts,En,L,Q,\[CapitalUpsilon]r,\[CapitalUpsilon]\[Theta],\[CapitalUpsilon]\[Phi],\[CapitalUpsilon]t,r1,r2,r3,r4,p3,p4,\[Alpha],\[Beta],zp,zm,assoc,var,\[Chi]0,\[Psi]0,
		r0,\[Theta]0,qt0,qr0,q\[Theta]0,q\[Phi]0,\[Lambda]t0,\[Lambda]r0,\[Lambda]\[Theta]0,\[Lambda]\[Phi]0,t,r,\[Theta],\[Phi],\[Psi],\[Chi],\[CapitalDelta]\[Lambda]r,\[Lambda]r,\[CapitalDelta]\[Lambda]\[Theta],\[Lambda]\[Theta],rC,\[Theta]C,\[CapitalDelta]r,\[CapitalDelta]\[Theta],
		\[Psi]r,\[Chi]\[Theta],NrMax,NthMax,pg,\[Lambda]rSample,\[Lambda]\[Theta]Sample,\[CapitalDelta]tr,\[CapitalDelta]\[Phi]r,\[CapitalDelta]t\[Theta],\[CapitalDelta]\[Phi]\[Theta],\[Phi]C,tC,zRoots,tInit,rInit,\[Theta]Init,\[Phi]Init, velocity,type},
	consts = KerrGeoConstantsOfMotionN[a,p,e,Qc];
	{En,L,Q} = Values[consts];
	
	(* Useful constants for \[Theta]-dependent calculations *)
	\[Beta]=a^2(1-En^2);
	\[Alpha]=L^2+Q+\[Beta];
	zp=Sqrt[(\[Alpha]+Sqrt[\[Alpha]^2-4 Q \[Beta]])/(2\[Beta])];
	zm=Sqrt[(\[Alpha]-Sqrt[\[Alpha]^2-4 Q \[Beta]])/(2\[Beta])];
	zRoots={ArcCos[zm],Pi-ArcCos[zm]};
	
	(* Useful constants for r-dependent calculations *)
    {r1,r2,r3,r4} = KerrGeoRadialRoots[a, p, e, x, Qc];
	
	(* Mino frequencies of orbit. I call Re, because some frequencies 
	are given as imaginary for restricted orbits. 
	Maybe something to fix with KerrGeoMinoFrequencies*)
	{\[CapitalUpsilon]r,\[CapitalUpsilon]\[Theta],\[CapitalUpsilon]\[Phi],\[CapitalUpsilon]t} = Values[KerrGeoMinoFrequencies[a,p,e,x,Qc]];
	If[e>0&&(Im[\[CapitalUpsilon]r]!=0||Re[\[CapitalUpsilon]r]==0),Message[KerrGeoOrbit::parametrization, "Unstable orbit. Aborting."]; Abort[]];
	If[r2<1+Sqrt[1-a^2], Message[KerrGeoOrbit::parametrization, "Unstable orbit. Aborting."]; Abort[]];
	{\[CapitalUpsilon]r,\[CapitalUpsilon]\[Theta],\[CapitalUpsilon]\[Phi],\[CapitalUpsilon]t} = Re[{\[CapitalUpsilon]r,\[CapitalUpsilon]\[Theta],\[CapitalUpsilon]\[Phi],\[CapitalUpsilon]t}];
	
	(*Parameterize r and \[Theta] in terms of Darwin-like parameters \[Psi] and \[Chi]*)
	r0[psi_]:=p M/(1+e Cos[psi]);
	\[Theta]0[chi_]:=ArcCos[zm Cos[chi]];
	
	(*Precision of sampling depends on precision of arguments*)
	pg=Min[{Precision[{a,p,e,x}],Precision[initPhases]}];
	If[pg==$MachinePrecision,
		\[Psi]r[Nr_]:=N[Table[2Pi i/Nr,{i,0,Nr-1}]];
		\[Chi]\[Theta][Nth_]:=N[Table[2Pi i/Nth,{i,0,Nth-1}]],
		\[Psi]r[Nr_]:=N[Table[2Pi i/Nr,{i,0,Nr-1}],1.3pg];
		\[Chi]\[Theta][Nth_]:=N[Table[2Pi i/Nth,{i,0,Nth-1}],1.3pg]
	];
	
	(*Solve for Mino time as a function of \[Psi] and \[Chi]*)
	\[CapitalDelta]\[Lambda]r=MinoRFastSpec[a,p,e,x,Qc];
	\[Lambda]r[psi_]:=\[Lambda]r[psi]=\[CapitalDelta]\[Lambda]r[psi];
	\[Lambda]rSample[Nr_]:=\[Lambda]r[\[Psi]r[Nr]];
	\[CapitalDelta]\[Lambda]\[Theta]=MinoThetaFastSpec[a,p,e,x,Qc];
	\[Lambda]\[Theta][chi_]:=\[Lambda]\[Theta][chi]=\[CapitalDelta]\[Lambda]\[Theta][chi];
	\[Lambda]\[Theta]Sample[Nth_]:=\[Lambda]\[Theta][\[Chi]\[Theta][Nth]];
	
	(*Find the inverse transformation of \[Psi] and \[Chi] as functions of \[Lambda] 
	using spectral integration*)
	If[e>0,
		\[Psi]=PhaseOfMinoFastSpec[\[CapitalUpsilon]r,\[Lambda]rSample],
		\[Psi][qr_]:=0
	];
	If[x^2<1,
		\[Chi]=PhaseOfMinoFastSpec[\[CapitalUpsilon]\[Theta],\[Lambda]\[Theta]Sample],
		\[Chi][q\[Theta]_]:=0
	];

	(*Spectral integration of t and \[Phi] as functions of \[Lambda]*)
	If[e>0,
		\[CapitalDelta]tr=TimeOfMinoFastSpecR[a,p,e,x,Qc,{\[CapitalUpsilon]r,\[Lambda]rSample}];
		\[CapitalDelta]\[Phi]r=PhiOfMinoFastSpecR[a,p,e,x,Qc,{\[CapitalUpsilon]r,\[Lambda]rSample}],
		\[CapitalDelta]tr[qr_]:=0;
		\[CapitalDelta]\[Phi]r[qr_]:=0;
	];
	If[x^2<1,
		(* Calculate theta dependence for non-equatorial orbits *)
		\[CapitalDelta]t\[Theta]=TimeOfMinoFastSpecTheta[a,p,e,x,{\[CapitalUpsilon]\[Theta],\[Lambda]\[Theta]Sample}];
		\[CapitalDelta]\[Phi]\[Theta]=PhiOfMinoFastSpecTheta[a,p,e,x,{\[CapitalUpsilon]\[Theta],\[Lambda]\[Theta]Sample}],
		(* No theta dependence for equatorial orbits *)
		\[CapitalDelta]t\[Theta][q\[Theta]_]:=0;
		\[CapitalDelta]\[Phi]\[Theta][q\[Theta]_]:=0;
	];

	(*Collect initial Mino time phases*)
	{qt0, qr0, q\[Theta]0, q\[Phi]0} = {initPhases[[1]], initPhases[[2]], initPhases[[3]], initPhases[[4]]};
	
	(* If the user specifies a valid set of initial coordinate positions, 
	find phases that give these initial positions *)
	{tInit,rInit,\[Theta]Init,\[Phi]Init}=OptionValue["InitialPosition"];
	If[{tInit,rInit,\[Theta]Init,\[Phi]Init}!={0,0,0,0},
		If[rInit<=r1&&rInit>=r2&&\[Theta]Init>=zRoots[[1]]&&\[Theta]Init<=zRoots[[2]],
			If[e==0,\[Psi]0=0,\[Psi]0=ArcCos[p M/(e rInit)-1/e]];
			If[zm==0,\[Chi]0=0,\[Chi]0=ArcCos[Cos[\[Theta]Init]/zm]];
			qt0=tInit;
			qr0=\[CapitalUpsilon]r*\[Lambda]r[\[Psi]0]+\[Psi]0;
			q\[Theta]0=\[CapitalUpsilon]\[Theta]*\[Lambda]\[Theta][\[Chi]0]+\[Chi]0;
			q\[Phi]0=\[Phi]Init,
			Message[KerrGeoOrbit::parametrization, "{t,r,\[Theta],\[Phi]} = "<>ToString[{tInit,rInit,\[Theta]Init,\[Phi]Init}]<>" is not a valid set of initial coordinates"]
		]
	];
	If[\[CapitalUpsilon]r==0,\[Lambda]r0=0,\[Lambda]r0=qr0/\[CapitalUpsilon]r];
	If[\[CapitalUpsilon]\[Theta]==0,\[Lambda]\[Theta]0=0,\[Lambda]\[Theta]0=q\[Theta]0/\[CapitalUpsilon]\[Theta]];
	
	(* Find integration constants for t and \[Phi], so that t(\[Lambda]=0)=qt0 and \[Phi](\[Lambda]=0)=q\[Phi]0 *)
	\[Phi]C=\[CapitalDelta]\[Phi]r[qr0]+\[CapitalDelta]\[Phi]\[Theta][q\[Theta]0];
	tC=\[CapitalDelta]tr[qr0]+\[CapitalDelta]t\[Theta][q\[Theta]0];

	t=Function[{Global`\[Lambda]}, Evaluate[ \[CapitalDelta]tr[\[CapitalUpsilon]r Global`\[Lambda] + qr0]+\[CapitalDelta]t\[Theta][\[CapitalUpsilon]\[Theta] Global`\[Lambda] + q\[Theta]0]+\[CapitalUpsilon]t Global`\[Lambda]+qt0-tC ], Listable];
	r=Function[{Global`\[Lambda]}, Evaluate[ r0[\[Psi][\[CapitalUpsilon]r  Global`\[Lambda] + qr0]+\[CapitalUpsilon]r Global`\[Lambda]+qr0] ], Listable];
	\[Theta]=Function[{Global`\[Lambda]}, Evaluate[ \[Theta]0[\[Chi][\[CapitalUpsilon]\[Theta]  Global`\[Lambda]+ q\[Theta]0]+\[CapitalUpsilon]\[Theta] Global`\[Lambda]+q\[Theta]0] ], Listable];
	\[Phi]=Function[{Global`\[Lambda]}, Evaluate[ \[CapitalDelta]\[Phi]r[\[CapitalUpsilon]r Global`\[Lambda] + qr0]+\[CapitalDelta]\[Phi]\[Theta][\[CapitalUpsilon]\[Theta] Global`\[Lambda] + q\[Theta]0]+\[CapitalUpsilon]\[Phi] Global`\[Lambda]+q\[Phi]0-\[Phi]C ], Listable];
	
	velocity = Values[KerrGeoFourVelocity[a,p,e,x,Qc,{initPhases[[2]],initPhases[[3]]}]];

	type = KerrGeoOrbitType[a,p,e,x];

	assoc = Association[
		"Parametrization"->"Mino",
		"Energy" -> En, 
		"AngularMomentum" -> L, 
		"CarterConstant" -> Q, 
		"ConstantsOfMotion" -> consts,
		"RadialFrequency" -> \[CapitalUpsilon]r,
		"PolarFrequency" ->  \[CapitalUpsilon]\[Theta],
		"AzimuthalFrequency" -> \[CapitalUpsilon]\[Phi],
		"Frequencies" -> <|"\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(r\)]\)" ->  \[CapitalUpsilon]r, "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Theta]\)]\)" ->  \[CapitalUpsilon]\[Theta], "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(\[Phi]\)]\)" ->  \[CapitalUpsilon]\[Phi] , "\!\(\*SubscriptBox[\(\[CapitalUpsilon]\), \(t\)]\)" ->  \[CapitalUpsilon]t|> ,
		"Trajectory" -> {t,r,\[Theta],\[Phi]},
		"TrajectoryDeltas" -> <|"\[CapitalDelta]tr"-> \[CapitalDelta]tr,"\[CapitalDelta]t\[Theta]"-> \[CapitalDelta]t\[Theta],"\[CapitalDelta]\[Phi]r"-> \[CapitalDelta]\[Phi]r,"\[CapitalDelta]\[Phi]\[Theta]"-> \[CapitalDelta]\[Phi]\[Theta]|>,
		"FourVelocity"-> velocity,
		"RadialRoots" -> {r1,r2,r3,r4},
		"PolarRoots" -> zRoots,
		"a" -> a,
		"p" -> p,
		"e" -> e,
		"Inclination" -> x,
		"Qc" -> Qc,
		"Type" -> type,
		"InitialPhases" -> {qt0, qr0, q\[Theta]0, q\[Phi]0}
		];
	
	KerrGeoOrbitFunction[a,p,e,x,Qc,assoc]
]


(* ::Section:: *)
(*KerrGeoOrbit and KerrGeoOrbitFuction*)


Options[KerrGeoOrbit] = {"Parametrization" -> "Mino", "Method" -> "Analytic"};
SyntaxInformation[KerrGeoOrbit] = {"ArgumentsPattern"->{_,_,OptionsPattern[]}};


KerrGeoOrbit[a_,p_,e_,x_,Qc_, initPhases:{_,_,_,_}:{0,0,0,0},OptionsPattern[]]:=Module[{param, method},
(*FIXME: add stability check but make it possible to turn it off*)

method = OptionValue["Method"];
param = OptionValue["Parametrization"];

If[param == "Darwin" && Abs[x]!=1, Message[KerrGeoOrbit::parametrization, "Darwin parameterization only valid for equatorial motion"]; Return[];];

If[Precision[{a,p,e,x}] > 30, method = "Analytic"];
If[e > 1, method = "Analytic"];

If[method == "FastSpec",

	If[param == "Mino",  If[PossibleZeroQ[a] || PossibleZeroQ[e], Return[KerrGeoOrbitMino[a, p, e, x, Qc,initPhases]], 
	Return[KerrGeoOrbitFastSpec[a, p, e, x,Qc, initPhases]]]];
	If[param == "Darwin", 
		If[PossibleZeroQ[a], Return[KerrGeoOrbitSchwarzDarwin[p, e]], Return[KerrGeoOrbitFastSpecDarwin[a,p,e,x,Qc,initPhases]]]
	];
	Message[KerrGeoOrbit::parametrization, "Unrecognized parametrization: " <> OptionValue["Parametrization"]];
	
];

If[method == "Analytic",
(*Changed "KerrGeoOrbitDarwin" to "KerrGeoOrbitEquatorialDarwin"*)
	If[param == "Mino", Return[KerrGeoOrbitMino[a, p, e, x, Qc,initPhases]]];
	If[param == "Phases", Return[KerrGeoOrbitPhases[a, p, e, x,Qc]]];
	If[param == "Darwin", 
		If[PossibleZeroQ[a], Return[KerrGeoOrbitSchwarzDarwin[p, e]], Return[KerrGeoOrbitEquatorialDarwin[a,p,e,x,Qc,initPhases]]]
	];
	Message[KerrGeoOrbit::parametrization, "Unrecognized parametrization: " <> OptionValue["Parametrization"]];

];

Message[KerrGeoOrbit::general, "Method " <> method <> " is not one of {FastSpec, Analytic}"];

]


KerrGeoOrbitFunction /:
 MakeBoxes[kgof:KerrGeoOrbitFunction[a_, p_, e_, x_, Qc_, assoc_], form:(StandardForm|TraditionalForm)] :=
 Module[{summary, extended},
  summary = {Row[{BoxForm`SummaryItem[{"a: ", a}], "  ",
                  BoxForm`SummaryItem[{"p: ", p}], "  ",
                  BoxForm`SummaryItem[{"e: ", e}], "  ",
                  BoxForm`SummaryItem[{"x: ", x}], "  ",
                  BoxForm`SummaryItem[{"Qc: ", Qc}]}],
             BoxForm`SummaryItem[{"Parametrization: ", assoc["Parametrization"]}]};
  extended = {BoxForm`SummaryItem[{"Energy: ", assoc["Energy"]}],
              BoxForm`SummaryItem[{"Angular Momentum: ", assoc["AngularMomentum"]}],
              BoxForm`SummaryItem[{"Carter Constant: ", assoc["CarterConstant"]}]};
  BoxForm`ArrangeSummaryBox[
    KerrGeoOrbitFunction,
    kgof,
    None,
    summary,
    extended,
    form]
];


KerrGeoOrbitFunction[a_, p_, e_, x_, Qc_, assoc_][\[Lambda]_/;StringQ[\[Lambda]] == False] := Through[assoc["Trajectory"][\[Lambda]]]
KerrGeoOrbitFunction[a_, p_, e_, x_, Qc_, assoc_][y_?StringQ] := assoc[y]
Keys[g_KerrGeoOrbitFunction]^:=Keys[g[[5]]]


(*KNOrbits=KerrGeoOrbit[0.8,12,0.1,1,0.001];
KNOrbits["Frequencies"]
KNOrbits["TrajectoryDeltas"]["\[CapitalDelta]tr"][4]*)
