(* Created with the Wolfram Language : www.wolfram.com *)
{(-(E0^2*r0^3*(d2S - 2*dS*m + (-2 + m^2)*S)) + 
   Lz^2*S*\[Omega]*((2*I)*r0^2 + (2*I)*rm*rp - (2*I)*r0*(-1 + rm + rp) - 
     r0^3*\[Omega]) + (2*I)*E0*Lz*(dS - m*S)*(2*(r0 - rm)*(r0 - rp) + 
     I*r0^3*\[Omega]))/(2*E0*r0^3*(r0 - rm)*(r0 - rp)), 
 ((2*I)*Lz*(dS - m*S))/r0^2, (Lz^2*(r0 - rm)*(r0 - rp)*S)/(2*E0*r0^4)}
